/* player.h - the farmer: movement, energy, levels. */
#ifndef PLAYER_H
#define PLAYER_H

#include "types.h"

void  player_init(Player *p, int x, int y);
bool  player_step(Player *p, const Farm *f, Direction d);   /* true if moved */
void  player_face_target(const Player *p, int *tx, int *ty);
int   player_xp_needed(int level);
int   player_max_energy(int level);
const char *tool_name(ToolType t);
const char *dir_name(Direction d);

#endif
