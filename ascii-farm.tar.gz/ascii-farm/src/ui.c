/*
 * ui.c - terminal handling, drawing and all menus/popups.
 *
 * Rendering model: every screen is appended to one in-memory buffer
 * (g_buf) and written with a single write() in ui_flush().  Positions for
 * overlays are absolute, 1-based (row, col) terminal coordinates.
 * The game screen is SCREEN_W x SCREEN_H (79 x 28).
 */
#include <ctype.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <termios.h>
#include <unistd.h>

#include "ui.h"
#include "crop.h"
#include "farm.h"
#include "game.h"
#include "inventory.h"
#include "player.h"
#include "shop.h"

/* ====================================================== output buffer ==== */

static char   g_buf[1 << 17];
static size_t g_len;

static void b_raw(const char *s, size_t n)
{
    if (g_len + n < sizeof g_buf) {
        memcpy(g_buf + g_len, s, n);
        g_len += n;
    }
}

static void b_puts(const char *s) { b_raw(s, strlen(s)); }

static void b_vprintf(const char *fmt, va_list ap)
{
    if (g_len + 1 >= sizeof g_buf) return;
    int n = vsnprintf(g_buf + g_len, sizeof g_buf - g_len, fmt, ap);
    if (n > 0) {
        size_t room = sizeof g_buf - g_len - 1;
        g_len += (size_t)n < room ? (size_t)n : room;
    }
}

static void b_goto(int row, int col)
{
    char tmp[32];
    snprintf(tmp, sizeof tmp, "\x1b[%d;%dH", row, col);
    b_puts(tmp);
}

void ui_begin(void)
{
    g_len = 0;
    b_puts(C_RESET);
}

void ui_flush(void)
{
    size_t off = 0;
    while (off < g_len) {
        ssize_t n = write(STDOUT_FILENO, g_buf + off, g_len - off);
        if (n <= 0) break;
        off += (size_t)n;
    }
    g_len = 0;
}

void ui_clear_screen(void)
{
    ui_begin();
    b_puts("\x1b[2J\x1b[H");
    ui_flush();
}

void ui_text(int row, int col, const char *fmt, ...)
{
    va_list ap;
    b_goto(row, col);
    va_start(ap, fmt);
    b_vprintf(fmt, ap);
    va_end(ap);
    b_puts(C_RESET);
}

void ui_box(int row, int col, int w, int h, const char *title)
{
    b_puts(C_RESET);
    for (int r = 0; r < h; r++) {
        b_goto(row + r, col);
        bool edge = (r == 0 || r == h - 1);
        b_puts(edge ? "+" : "|");
        for (int i = 0; i < w - 2; i++) b_puts(edge ? "-" : " ");
        b_puts(edge ? "+" : "|");
    }
    if (title && *title) {
        int tl = (int)strlen(title);
        b_goto(row, col + (w - tl) / 2);
        b_puts(C_BYELLOW);
        b_puts(title);
        b_puts(C_RESET);
    }
}

/* Visible length of a string, ignoring ANSI escape sequences. */
static int vis_len(const char *s)
{
    int n = 0;
    while (*s) {
        if (*s == 27) {
            while (*s && !isalpha((unsigned char)*s)) s++;
            if (*s) s++;
        } else {
            n++;
            s++;
        }
    }
    return n;
}

/* Write s truncated/padded to exactly `width` visible columns. */
static void b_fit(const char *s, int width)
{
    int vis = 0;
    for (const char *p = s; *p;) {
        if (*p == 27) {
            const char *q = p;
            while (*q && !isalpha((unsigned char)*q)) q++;
            if (*q) q++;
            b_raw(p, (size_t)(q - p));
            p = q;
        } else {
            if (vis >= width) break;
            b_raw(p, 1);
            vis++;
            p++;
        }
    }
    b_puts(C_RESET);
    for (; vis < width; vis++) b_puts(" ");
}

/* ===================================================== terminal & input === */

static struct termios g_orig;
static bool g_have_term = false;
static bool g_active = false;

static void out_now(const char *s)
{
    size_t len = strlen(s);
    ssize_t r = write(STDOUT_FILENO, s, len);
    (void)r;
}

static void on_signal(int sig)
{
    (void)sig;
    ui_shutdown();
    _exit(0);
}

void ui_init(void)
{
    if (g_active) return;
    if (isatty(STDIN_FILENO) && tcgetattr(STDIN_FILENO, &g_orig) == 0) {
        struct termios raw = g_orig;
        raw.c_lflag &= (tcflag_t)~(ICANON | ECHO);
        raw.c_cc[VMIN] = 1;
        raw.c_cc[VTIME] = 0;
        tcsetattr(STDIN_FILENO, TCSANOW, &raw);
        g_have_term = true;
    }
    g_active = true;
    out_now("\x1b[?1049h\x1b[?25l\x1b[2J\x1b[H");   /* alt screen, hide cursor */
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    atexit(ui_shutdown);
}

void ui_shutdown(void)
{
    if (!g_active) return;
    g_active = false;
    out_now("\x1b[0m\x1b[?25h\x1b[?1049l");
    if (g_have_term) tcsetattr(STDIN_FILENO, TCSANOW, &g_orig);
}

bool ui_terminal_big_enough(void)
{
    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) != 0 || ws.ws_col == 0) return true;
    return ws.ws_col >= SCREEN_W && ws.ws_row >= SCREEN_H;
}

/* Wait up to ms milliseconds for input (ms < 0 = forever). */
static bool wait_input(int ms)
{
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds);
    if (ms < 0) return select(STDIN_FILENO + 1, &fds, NULL, NULL, NULL) > 0;
    struct timeval tv = { ms / 1000, (ms % 1000) * 1000 };
    return select(STDIN_FILENO + 1, &fds, NULL, NULL, &tv) > 0;
}

/*
 * Returns an ASCII code, KEY_UP/DOWN/LEFT/RIGHT, KEY_ESC, KEY_NONE (timeout)
 * or KEY_EOF (stdin closed).
 */
static int g_pushback = KEY_NONE;     /* a key read ahead after a lone ESC */

int ui_get_key(int timeout_ms)
{
    if (g_pushback != KEY_NONE) {
        int k = g_pushback;
        g_pushback = KEY_NONE;
        return k;
    }
    if (!wait_input(timeout_ms)) return KEY_NONE;
    unsigned char c;
    ssize_t n = read(STDIN_FILENO, &c, 1);
    if (n == 0) return KEY_EOF;
    if (n < 0) return KEY_NONE;

    if (c == 27) {                       /* ESC or an escape sequence */
        if (!wait_input(40)) return KEY_ESC;
        unsigned char c2;
        if (read(STDIN_FILENO, &c2, 1) != 1) return KEY_ESC;
        if (c2 != '[' && c2 != 'O') { g_pushback = c2; return KEY_ESC; }
        unsigned char c3;
        if (read(STDIN_FILENO, &c3, 1) != 1) return KEY_ESC;
        switch (c3) {
        case 'A': return KEY_UP;
        case 'B': return KEY_DOWN;
        case 'C': return KEY_RIGHT;
        case 'D': return KEY_LEFT;
        default:
            while (isdigit(c3) || c3 == ';') {      /* swallow e.g. ESC[3~ */
                if (read(STDIN_FILENO, &c3, 1) != 1) break;
            }
            return KEY_NONE;
        }
    }
    return c;
}

/* ===================================================== game rendering ==== */

static unsigned hash2(int x, int y)
{
    unsigned h = (unsigned)x * 73856093u ^ (unsigned)y * 19349663u;
    h ^= h >> 13;
    h *= 0x5bd1e995u;
    h ^= h >> 15;
    return h;
}

static bool is_night(const GameState *gs)
{
    int hour = (gs->minutes / 60) % 24;
    return hour >= 20 || hour < 6;
}

static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

/* Work out the glyph, colour and background of one map cell. */
static void cell_look(const GameState *gs, int x, int y, char *ch, char *fg, int *bg)
{
    static const char *grass[4]  = { "32", "1;32", "33", "37" };
    static const char *trees[4]  = { "1;32", "32", "1;31", "1;37" };
    static const char *flowers[4] = { "1;31", "1;35", "1;33", "1;36" };
    const Tile *t = &gs->farm.tiles[y][x];
    Season season = SEASON_OF_DAY(gs->day);
    unsigned h = hash2(x, y);
    bool rainy = gs->weather.today >= WEATHER_RAINY;

    *bg = 0;
    *ch = t->ch;
    strcpy(fg, "37");

    switch ((TileType)t->type) {
    case TILE_GRASS:
        *ch = (h % 9 == 0) ? ',' : ((h % 23 == 0) ? '"' : '.');
        strcpy(fg, grass[season]);
        break;
    case TILE_PATH:
        *ch = ':';
        strcpy(fg, "33");
        break;
    case TILE_FENCE:
        *ch = '#';
        strcpy(fg, "33");
        break;
    case TILE_WATER: {
        bool shimmer = ((x + y + (int)(gs->frame / 2)) % 3) == 0;
        *ch = shimmer ? '~' : '~';
        strcpy(fg, shimmer ? "1;36" : "1;34");
        break;
    }
    case TILE_TREE:
        *ch = 'T';
        strcpy(fg, (h % 3 == 0) ? "32" : trees[season]);
        break;
    case TILE_FLOWER:
        *ch = '*';
        strcpy(fg, flowers[h % 4]);
        break;
    case TILE_ROCK:
        *ch = 'o';
        strcpy(fg, "1;30");
        break;
    case TILE_SOIL:
        if (t->crop == NO_CROP) {
            *ch = '=';
            strcpy(fg, "33");
        } else if (t->withered) {
            *ch = 'x';
            strcpy(fg, "1;30");
        } else {
            *ch = crop_glyph(t);
            snprintf(fg, 24, "%s%s", crop_ready(t) ? "1;" : "", crop_info(t->crop)->color);
        }
        if (t->watered) *bg = 44;
        break;
    case TILE_HOUSE:
    case TILE_DOOR:
        if (*ch == '^' || *ch == '/' || *ch == '\\') strcpy(fg, "1;31");
        else if (*ch == 'o') strcpy(fg, is_night(gs) ? "1;33" : "1;36");
        else if (*ch == 'D') strcpy(fg, "1;31");
        else strcpy(fg, "33");
        break;
    case TILE_SHOP:
        strcpy(fg, (*ch == '$') ? "1;33" : "1;37");
        break;
    case TILE_CHEST:
        *ch = 'C';
        strcpy(fg, "1;35");
        break;
    }

    /* Falling rain / snow over open ground. */
    if (rainy && (t->type == TILE_GRASS || t->type == TILE_PATH || t->type == TILE_FLOWER) &&
        ((x * 7 + y * 13 + (int)(gs->frame * 3)) % 11) == 0) {
        if (season == SEASON_WINTER) { *ch = '*'; strcpy(fg, "1;37"); }
        else { *ch = (gs->weather.today == WEATHER_STORMY) ? '/' : '\''; strcpy(fg, "36"); }
    }

    /* Animals, then the player, on top. */
    for (int i = 0; i < MAX_ANIMALS; i++) {
        if (gs->animals[i].glyph && gs->animals[i].x == x && gs->animals[i].y == y) {
            *ch = gs->animals[i].glyph;
            strcpy(fg, "1;37");
        }
    }
    if (gs->player.x == x && gs->player.y == y) {
        *ch = '@';
        strcpy(fg, "1;33;41");
    }
}

static void bar(char *out, size_t n, int val, int max, int width, const char *color)
{
    int filled = max > 0 ? val * width / max : 0;
    filled = clampi(filled, 0, width);
    char on[64], off[64];
    memset(on, '#', (size_t)filled);
    on[filled] = '\0';
    memset(off, '-', (size_t)(width - filled));
    off[width - filled] = '\0';
    snprintf(out, n, "[%s%s" C_RESET C_DIM "%s" C_RESET "]", color, on, off);
}

static const char *weather_color(WeatherType w)
{
    switch (w) {
    case WEATHER_SUNNY:  return C_BYELLOW;
    case WEATHER_CLOUDY: return C_WHITE;
    case WEATHER_RAINY:  return C_BCYAN;
    default:             return "\x1b[1;35m";
    }
}

static const char *season_color(Season s)
{
    static const char *c[4] = { C_BGREEN, C_BYELLOW, C_RED, C_BCYAN };
    return c[s];
}

/* Three short lines describing the tile the player faces. */
static void describe_target(const GameState *gs, char *l1, char *l2, char *l3, size_t n)
{
    int tx, ty;
    player_face_target(&gs->player, &tx, &ty);
    l1[0] = l2[0] = l3[0] = '\0';
    const Tile *t = farm_tile_c(&gs->farm, tx, ty);
    if (!t) { snprintf(l1, n, " Edge of the world"); return; }

    switch ((TileType)t->type) {
    case TILE_GRASS:  snprintf(l1, n, " Grass");          snprintf(l2, n, " X: till the soil"); break;
    case TILE_FLOWER: snprintf(l1, n, " Wildflowers");    snprintf(l2, n, " X: till the soil"); break;
    case TILE_PATH:   snprintf(l1, n, " Dirt path"); break;
    case TILE_FENCE:  snprintf(l1, n, " Wooden fence"); break;
    case TILE_WATER:  snprintf(l1, n, " Pond water");     snprintf(l2, n, " E: refill the can"); break;
    case TILE_TREE:   snprintf(l1, n, " A tall tree");    snprintf(l2, n, " E: chop for wood"); break;
    case TILE_ROCK:   snprintf(l1, n, " A mossy rock"); break;
    case TILE_HOUSE:  snprintf(l1, n, " Your farmhouse"); break;
    case TILE_DOOR:   snprintf(l1, n, " Front door");     snprintf(l2, n, " E: go to bed"); break;
    case TILE_SHOP:   snprintf(l1, n, " The market");      snprintf(l2, n, " E or B: trade"); break;
    case TILE_CHEST:  snprintf(l1, n, " Storage chest");   snprintf(l2, n, " E or C: open"); break;
    case TILE_SOIL:
        if (t->crop == NO_CROP) {
            snprintf(l1, n, " Tilled soil %s", t->watered ? "(wet)" : "(dry)");
            snprintf(l2, n, " P: plant a seed");
        } else if (t->withered) {
            snprintf(l1, n, " Withered %s", crop_info(t->crop)->name);
            snprintf(l2, n, " H: clear it away");
        } else if (crop_ready(t)) {
            snprintf(l1, n, " %sRIPE %s!" C_RESET, C_BGREEN, crop_info(t->crop)->name);
            snprintf(l2, n, " H: harvest it");
        } else {
            snprintf(l1, n, " %s %s", crop_info(t->crop)->name, t->watered ? "(wet)" : "(dry)");
            snprintf(l2, n, " Stage %d/4, %dd left", crop_stage(t) + 1, crop_days_left(t));
            snprintf(l3, n, t->watered ? " F: fertilize" : " R: water it!");
        }
        break;
    }
}

static void build_panel(const GameState *gs, char panel[][160])
{
    const Player *p = &gs->player;
    const CropInfo *seed = crop_info(p->seed);
    char wbar[96], l1[96], l2[96], l3[96];
    int i = 0;

    snprintf(panel[i++], 160, " Pos %d,%d  facing %s", p->x, p->y, dir_name(p->facing));
    snprintf(panel[i++], 160, " Area: " C_BGREEN "%s", farm_area_name(p->x, p->y));
    snprintf(panel[i++], 160, " Tool: " C_BYELLOW "%s", tool_name(p->tool));
    snprintf(panel[i++], 160, " Seed: \x1b[%sm%s" C_RESET " x%d", seed->color, seed->name, gs->inv.seeds[p->seed]);
    bar(wbar, sizeof wbar, p->waterLeft, p->waterMax, 8, C_BCYAN);
    snprintf(panel[i++], 160, " Can %s %d/%d", wbar, p->waterLeft, p->waterMax);
    snprintf(panel[i++], 160, " Wood %d   Fertilizer %d", gs->inv.wood, gs->inv.fertilizer);
    snprintf(panel[i++], 160, C_DIM "-------- Facing --------");
    describe_target(gs, l1, l2, l3, sizeof l1);
    snprintf(panel[i++], 160, "%s", l1);
    snprintf(panel[i++], 160, "%s", l2);
    snprintf(panel[i++], 160, "%s", l3);
    snprintf(panel[i++], 160, C_DIM "------ Harvested ------");
    for (int row = 0; row < 2; row++) {
        char tmp[160] = "";
        for (int c = row * 3; c < row * 3 + 3; c++) {
            char cell[48];
            snprintf(cell, sizeof cell, "\x1b[%sm%.3s" C_RESET ":%-2d", crop_info(c)->color,
                     crop_info(c)->name, gs->inv.crops[c]);
            strcat(tmp, cell);
            strcat(tmp, " ");
        }
        snprintf(panel[i++], 160, " %.150s", tmp);
    }
    snprintf(panel[i++], 160, " Chest items: %d", inv_chest_total(&gs->inv));
    snprintf(panel[i++], 160, " Goal $%d/%d", p->money, WIN_MONEY);
}

/* Row of the main frame: "| content |" padded to the full width. */
static void full_row(const char *content)
{
    b_puts("|");
    b_fit(content, SCREEN_W - 2);
    b_puts("|\x1b[K\n");
}

static void border_full(void)
{
    b_puts("+");
    for (int i = 0; i < SCREEN_W - 2; i++) b_puts("-");
    b_puts("+\x1b[K\n");
}

static void border_split(bool closeTop)
{
    (void)closeTop;
    b_puts("+");
    for (int i = 0; i < VIEW_W; i++) b_puts("-");
    b_puts("+");
    for (int i = 0; i < PANEL_W; i++) b_puts("-");
    b_puts("+\x1b[K\n");
}

void ui_render_game(const GameState *gs)
{
    const Player *p = &gs->player;
    Season season = SEASON_OF_DAY(gs->day);
    bool night = is_night(gs);
    char line[512], ebar[96], xbar[96];

    b_puts("\x1b[H");
    border_full();

    /* Title (centred). */
    const char *title = "=[ ASCII FARMING SIMULATOR ]=";
    snprintf(line, sizeof line, "%*s" C_BYELLOW "%s" C_RESET, (SCREEN_W - 2 - (int)strlen(title)) / 2, "", title);
    full_row(line);

    /* Status line 1: calendar, clock, weather. */
    int hour = (gs->minutes / 60) % 24, mins = gs->minutes % 60;
    const char *part = hour < 6 ? "Night" : hour < 12 ? "Morning" : hour < 17 ? "Afternoon" : hour < 21 ? "Evening" : "Night";
    snprintf(line, sizeof line,
             " Day " C_BWHITE "%d" C_RESET "/%d  %s%s %d/%d" C_RESET " Y%d " C_DIM "|" C_RESET " "
             C_BWHITE "%02d:%02d" C_RESET " %s " C_DIM "|" C_RESET " %s%s" C_RESET " (tomorrow: %s)",
             gs->day, GAME_DAY_LIMIT, season_color(season), season_name(season),
             DAY_IN_SEASON(gs->day), DAYS_PER_SEASON, YEAR_OF_DAY(gs->day),
             hour, mins, part,
             weather_color(gs->weather.today), weather_name(gs->weather.today, season),
             weather_name(gs->weather.tomorrow, SEASON_OF_DAY(gs->day + 1)));
    full_row(line);

    /* Status line 2: money, energy, level. */
    int eper = p->maxEnergy ? p->energy * 100 / p->maxEnergy : 0;
    bar(ebar, sizeof ebar, p->energy, p->maxEnergy, 10, eper > 50 ? C_BGREEN : eper > 25 ? C_BYELLOW : C_BRED);
    bar(xbar, sizeof xbar, p->xp, player_xp_needed(p->level), 6, C_BCYAN);
    snprintf(line, sizeof line,
             " Money: " C_BYELLOW "$%d" C_RESET " " C_DIM "|" C_RESET " Energy %s %d/%d " C_DIM "|" C_RESET
             " Lv%d XP %s %d/%d%s",
             p->money, ebar, p->energy, p->maxEnergy, p->level, xbar, p->xp,
             player_xp_needed(p->level), gs->festival ? "  " C_BYELLOW "*FAIR*" C_RESET : "");
    full_row(line);
    border_split(true);

    /* Map viewport + side panel. */
    int camX = clampi(p->x - VIEW_W / 2, 0, MAP_W - VIEW_W);
    int camY = clampi(p->y - VIEW_H / 2, 0, MAP_H - VIEW_H);
    int tx, ty;
    player_face_target(p, &tx, &ty);

    char panel[VIEW_H][160];
    for (int i = 0; i < VIEW_H; i++) panel[i][0] = '\0';
    build_panel(gs, panel);

    for (int vy = 0; vy < VIEW_H; vy++) {
        char last[64] = "";
        b_puts("|");
        for (int vx = 0; vx < VIEW_W; vx++) {
            int x = camX + vx, y = camY + vy, bg;
            char ch, fg[24], st[64];
            cell_look(gs, x, y, &ch, fg, &bg);
            bool rev = (x == tx && y == ty && !(x == p->x && y == p->y));
            snprintf(st, sizeof st, "\x1b[0%s;%s%s%sm", night ? ";2" : "", fg,
                     bg ? ";44" : "", rev ? ";7" : "");
            if (strcmp(st, last) != 0) { b_puts(st); strcpy(last, st); }
            b_raw(&ch, 1);
        }
        b_puts(C_RESET "|");
        b_fit(panel[vy], PANEL_W);
        b_puts("|\x1b[K\n");
    }
    border_split(false);

    /* Message log. */
    for (int i = 0; i < MSG_COUNT; i++) {
        snprintf(line, sizeof line, " %s%s" C_RESET, i == MSG_COUNT - 1 ? C_BWHITE "> " : C_DIM "  ", gs->msg[i]);
        full_row(line);
    }
    border_full();

    /* Help bar. */
    full_row(" [WASD]Move [X]Till [P]Plant [R]Water [H]Harvest [F]Fert [E]Use/Interact");
    full_row(" [1-6]Seed [T]Tool [B]Shop [C]Chest [I]Inv [N]Sleep [Esc]Pause [?]Help");
    b_puts("+");
    for (int i = 0; i < SCREEN_W - 2; i++) b_puts("-");
    b_puts("+");                      /* no newline: never scroll the screen */
}

/* =========================================================== popups ====== */

static void draw_popup(const GameState *gs, const char *title, const char *text, const char *prompt)
{
    char tmp[3072];
    const char *lines[48];
    int n = 0;
    snprintf(tmp, sizeof tmp, "%s", text);
    for (char *p = tmp; p && n < 48;) {
        lines[n++] = p;
        char *nl = strchr(p, '\n');
        if (nl) { *nl = '\0'; p = nl + 1; } else p = NULL;
    }
    int maxw = vis_len(title) + 2;
    if (prompt && vis_len(prompt) > maxw) maxw = vis_len(prompt);
    for (int i = 0; i < n; i++)
        if (vis_len(lines[i]) > maxw) maxw = vis_len(lines[i]);
    int w = clampi(maxw + 6, 20, SCREEN_W - 2);
    int h = n + 5;
    int row = (SCREEN_H - h) / 2 + 1, col = (SCREEN_W - w) / 2 + 1;
    if (row < 1) row = 1;

    ui_begin();
    if (gs) ui_render_game(gs); else b_puts("\x1b[2J");
    ui_box(row, col, w, h, title);
    for (int i = 0; i < n; i++) ui_text(row + 2 + i, col + 3, "%s", lines[i]);
    if (prompt) ui_text(row + n + 3, col + 3, C_DIM "%s", prompt);
    ui_flush();
}

void ui_popup(const GameState *gs, const char *title, const char *text)
{
    draw_popup(gs, title, text, "[press any key]");
    int k;
    do { k = ui_get_key(-1); } while (k == KEY_NONE);
}

bool ui_confirm(const GameState *gs, const char *question)
{
    draw_popup(gs, " CONFIRM ", question, "[Y] Yes     [N] No");
    for (;;) {
        int k = ui_get_key(-1);
        if (k == KEY_EOF) return false;
        if (k == 'y' || k == 'Y') return true;
        if (k == 'n' || k == 'N' || k == KEY_ESC) return false;
    }
}

int ui_pause_menu(const GameState *gs)
{
    draw_popup(gs, " PAUSED ",
               "[1] Resume\n[2] Save game\n[3] Load game\n[4] How to play\n[5] Quit to main menu",
               "Choose 1-5  (Esc = resume)");
    for (;;) {
        int k = ui_get_key(-1);
        if (k == KEY_EOF) return PAUSE_QUIT;
        if (k == KEY_ESC || k == '1' || k == 'p') return PAUSE_RESUME;
        if (k == '2') return PAUSE_SAVE;
        if (k == '3') return PAUSE_LOAD;
        if (k == '4') return PAUSE_HELP;
        if (k == '5') return PAUSE_QUIT;
    }
}

void ui_help(const GameState *gs)
{
    ui_popup(gs, " HOW TO PLAY ",
        "CONTROLS\n"
        " W A S D / Arrows  Move (you also turn to face that tile)\n"
        " X  Till grass with the hoe      P  Plant the selected seed\n"
        " R  Water a crop                 H  Harvest ripe / clear dead crop\n"
        " F  Fertilize (+1 growth day)    E  Use tool or interact with the tile\n"
        " T  Cycle tool   1-6 or G  Choose seed   B  Shop   C  Chest\n"
        " I  Inventory & crop guide       N  Sleep / end the day\n"
        " Esc  Pause (save/load)          Q  Quit to main menu   ?  This help\n"
        "\n"
        "LEGEND\n"
        " @ you   . grass   # fence   ~ water   T tree   = tilled soil   o rock\n"
        " s y Y F  crop stages (F = ripe)   x dead crop   H house   $ market\n"
        " C chest   c chicken   * flower   : path        (blue ground = watered)\n"
        "\n"
        "HOW TO PLAY\n"
        " 1. Buy seeds at the market ($). Stand next to it and press B.\n"
        " 2. Face grass in the fenced field, till (X), plant (P), water (R).\n"
        " 3. Refill your can at the pond: face the water and press E.\n"
        " 4. Crops grow one day per night if watered. Rain waters for free!\n"
        " 5. Harvest ripe 'F' crops (H), then sell them at the market.\n"
        " 6. Each action costs energy and time. Sleep (N) to start a new day;\n"
        "    sleeping in your house restores the most energy.\n"
        " 7. Seasons change every 7 days: unripe crops that dislike the new\n"
        "    season die. Reach $10,000 or level 10 within 84 days to win!");
}

void ui_inventory(const GameState *gs)
{
    const Inventory *inv = &gs->inv;
    const Player *p = &gs->player;
    char seasons[24];
    int planted, ripe;
    farm_count_crops(&gs->farm, &planted, &ripe);

    ui_begin();
    ui_render_game(gs);
    ui_box(4, 5, 70, 21, " INVENTORY & CROP GUIDE ");
    ui_text(6, 8, C_BWHITE "Crop      Seeds  Bag  Chest  Sells  Grow  Lv  Seasons" C_RESET);
    for (int c = 0; c < CROP_COUNT; c++) {
        const CropInfo *ci = crop_info(c);
        crop_season_str(c, seasons, sizeof seasons);
        ui_text(7 + c, 8, "\x1b[%sm%-9s" C_RESET " %5d %4d %6d  $%-4d %2dd%s  %2d  %s",
                ci->color, ci->name, inv->seeds[c], inv->crops[c], inv->chest[c],
                shop_sell_price(gs, c), ci->growDays, ci->regrowDays ? "+" : " ",
                ci->minLevel, seasons);
    }
    ui_text(14, 8, C_DIM "'+' = keeps producing after harvest. Sell prices change daily." C_RESET);
    ui_text(16, 8, "Wood: %d    Fertilizer: %d    Watering can: %d/%d",
            inv->wood, inv->fertilizer, p->waterLeft, p->waterMax);
    ui_text(17, 8, "Level %d   XP %d/%d   Max energy %d", p->level, p->xp,
            player_xp_needed(p->level), p->maxEnergy);
    ui_text(18, 8, "Crops growing: %d (%d ripe)   Total harvested: %d", planted, ripe, gs->totalHarvested);
    ui_text(19, 8, "Total earned: $%ld   Times passed out: %d", gs->totalEarned, gs->passouts);
    ui_text(20, 8, "Selected seed: %s   Tool: %s", crop_info(p->seed)->name, tool_name(p->tool));
    ui_text(22, 8, C_DIM "[press any key]" C_RESET);
    ui_flush();
    int k;
    do { k = ui_get_key(-1); } while (k == KEY_NONE);
}

/* ========================================================= main menu ===== */

static void art_char(char c)
{
    const char *col;
    switch (c) {
    case '^': case '/': case '\\': case 'D': col = "1;31"; break;
    case 'H': case '|': case '=': case '#': case ':': col = "33"; break;
    case 'o': col = "1;36"; break;
    case 'T': col = "1;32"; break;
    case '~': col = "1;34"; break;
    case 's': case 'y': case 'Y': case '.': case ',': col = "32"; break;
    case 'F': case '$': col = "1;33"; break;
    case '*': col = "1;35"; break;
    case 'c': case '@': col = "1;37"; break;
    default:  col = "1;37"; break;
    }
    char tmp[24];
    snprintf(tmp, sizeof tmp, "\x1b[%sm%c", col, c);
    b_puts(tmp);
}

int ui_main_menu(bool hasSave)
{
    static const char *ART[] = {
        "                 /^^^^^\\                         /$$$$$$\\            ",
        "        T        |HoHoH|              T          |MARKET|     T      ",
        "       TTT       |HHDHH|     c       TTT         |$$$$$$|    TTT     ",
        "   ..,..T..,.,..,.:.,...,..,.,..:..,....,...,....:::::::..,..T.,..   ",
        "   ,.##############:#############...*.,.,..~~~~~~~~~~~~~~.,.,.,..    ",
        "   .,#=s=s=y=y=Y=Y=F=F=s=y=Y=F=#.,..,.....~~~~~~~~~~~~~~~~~.,..,.   ",
        "   ..#=s=y=y=Y=Y=F=F=s=s=Y=F=F=#,..*..,....~~~~~~~~~~~~~~.,...,..   ",
        "   ,.##############:#############..,..,.,...,~~~~~~~~~.,..,...,.,   ",
    };
    static const char *ITEMS[4] = { "New Game", "Continue", "How to Play", "Quit" };
    int sel = hasSave ? 1 : 0;

    for (;;) {
        ui_begin();
        b_puts("\x1b[2J\x1b[H");
        ui_text(2, 6, C_BYELLOW "+==========================================================+");
        ui_text(3, 6, C_BYELLOW "|" C_BWHITE "      A S C I I   F A R M I N G   S I M U L A T O R       " C_BYELLOW "|");
        ui_text(4, 6, C_BYELLOW "+==========================================================+");
        for (int r = 0; r < 8; r++) {
            b_goto(6 + r, 5);
            for (const char *s = ART[r]; *s; s++) art_char(*s);
            b_puts(C_RESET);
        }
        for (int i = 0; i < 4; i++) {
            bool disabled = (i == MENU_CONTINUE && !hasSave);
            ui_text(16 + i * 2, 28, "%s%s %d. %-12s%s", i == sel ? C_BGREEN "> " : "  ",
                    disabled ? C_DIM : (i == sel ? C_BWHITE : C_WHITE), i + 1, ITEMS[i],
                    i == sel ? C_BGREEN " <" : "");
        }
        ui_text(25, 12, C_DIM "W/S or arrows to choose, Enter to select, or press 1-4." C_RESET);
        ui_text(26, 12, C_DIM "Needs a terminal of at least 80 x 28 characters." C_RESET);
        ui_flush();

        int k = ui_get_key(-1);
        if (k == KEY_EOF) return MENU_QUIT;
        if (k == KEY_NONE) continue;
        if (k == KEY_UP || k == 'w' || k == 'W') sel = (sel + 3) % 4;
        else if (k == KEY_DOWN || k == 's' || k == 'S') sel = (sel + 1) % 4;
        else if (k >= '1' && k <= '4') { sel = k - '1'; k = '\n'; }
        if (k == '\n' || k == '\r' || k == ' ') {
            if (sel == MENU_CONTINUE && !hasSave) continue;
            return sel;
        }
        if (k == 'q' || k == 'Q') return MENU_QUIT;
    }
}
