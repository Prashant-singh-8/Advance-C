/*
 * game.c - the coordinator.
 *
 * Owns the rules that tie the other modules together: the clock, sleeping and
 * the new-day sequence, weather and random events, player actions, levelling,
 * win/lose checks and the main loop.
 */
#include <ctype.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "game.h"
#include "crop.h"
#include "farm.h"
#include "inventory.h"
#include "player.h"
#include "save.h"
#include "shop.h"
#include "ui.h"

/* ------------------------------------------------------------ name tables */

const char *season_name(Season s)
{
    static const char *n[4] = { "Spring", "Summer", "Autumn", "Winter" };
    return n[s];
}

const char *weather_name(WeatherType w, Season s)
{
    switch (w) {
    case WEATHER_SUNNY:  return "Sunny";
    case WEATHER_CLOUDY: return "Cloudy";
    case WEATHER_RAINY:  return s == SEASON_WINTER ? "Snowy" : "Rainy";
    default:             return s == SEASON_WINTER ? "Blizzard" : "Stormy";
    }
}

/* ----------------------------------------------------------- message log */

void game_msg(GameState *gs, const char *fmt, ...)
{
    for (int i = 0; i < MSG_COUNT - 1; i++)
        memcpy(gs->msg[i], gs->msg[i + 1], MSG_LEN);
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(gs->msg[MSG_COUNT - 1], MSG_LEN, fmt, ap);
    va_end(ap);
}

/* ------------------------------------------------------ weather & markets */

static WeatherType roll_weather(Season s)
{
    /* percent chance of sunny / cloudy / rainy / stormy for each season */
    static const int table[4][4] = {
        { 40, 25, 28, 7 },    /* spring */
        { 60, 20, 14, 6 },    /* summer */
        { 35, 30, 29, 6 },    /* autumn */
        { 40, 35, 20, 5 },    /* winter */
    };
    int r = rand() % 100, acc = 0;
    for (int i = 0; i < 4; i++) {
        acc += table[s][i];
        if (r < acc) return (WeatherType)i;
    }
    return WEATHER_SUNNY;
}

static void roll_prices(GameState *gs)
{
    for (int c = 0; c < CROP_COUNT; c++) {
        gs->priceMod[c] = 85 + rand() % 41;          /* 85% .. 125% */
        if (gs->festival) gs->priceMod[c] += 25;
    }
}

static void init_animals(GameState *gs)
{
    static const int pos[MAX_ANIMALS][2] = { { 27, 11 }, { 36, 12 }, { 30, 12 }, { 45, 11 } };
    for (int i = 0; i < MAX_ANIMALS; i++) {
        gs->animals[i].x = gs->animals[i].homeX = pos[i][0];
        gs->animals[i].y = gs->animals[i].homeY = pos[i][1];
        gs->animals[i].glyph = 'c';
    }
}

/* Wander about on animation ticks: purely cosmetic. */
static void update_animals(GameState *gs)
{
    static const int dx[4] = { 0, 0, -1, 1 }, dy[4] = { -1, 1, 0, 0 };
    for (int i = 0; i < MAX_ANIMALS; i++) {
        Animal *a = &gs->animals[i];
        if (rand() % 3 != 0) continue;
        int d = rand() % 4, nx = a->x + dx[d], ny = a->y + dy[d];
        const Tile *t = farm_tile_c(&gs->farm, nx, ny);
        if (!t || t->type != TILE_GRASS) continue;
        if (abs(nx - a->homeX) > 6 || abs(ny - a->homeY) > 3) continue;
        if (nx == gs->player.x && ny == gs->player.y) continue;
        a->x = nx;
        a->y = ny;
    }
}

/* ------------------------------------------------------------------ setup */

void game_new(GameState *gs)
{
    memset(gs, 0, sizeof *gs);
    farm_generate(&gs->farm);
    player_init(&gs->player, 33, 10);
    inv_init(&gs->inv);
    gs->inv.seeds[CROP_WHEAT] = 6;
    gs->inv.seeds[CROP_CARROT] = 4;
    gs->day = 1;
    gs->minutes = START_MINUTES;
    gs->weather.today = WEATHER_SUNNY;
    gs->weather.tomorrow = roll_weather(SEASON_OF_DAY(2));
    roll_prices(gs);
    init_animals(gs);
    game_msg(gs, "Welcome to your farm! Press ? for help.");
    game_msg(gs, "Tip: face grass in the fenced field, press X to till, P to plant.");
    game_msg(gs, "Refill your can at the pond (E) and buy more seeds at the market (B).");
}

/* ----------------------------------------------------------------- xp ---- */

void game_gain_xp(GameState *gs, int xp)
{
    Player *p = &gs->player;
    p->xp += xp;
    while (p->level < MAX_LEVEL && p->xp >= player_xp_needed(p->level)) {
        p->xp -= player_xp_needed(p->level);
        p->level++;
        p->maxEnergy = player_max_energy(p->level);
        p->energy += 20;
        if (p->energy > p->maxEnergy) p->energy = p->maxEnergy;
        game_msg(gs, "LEVEL UP! You are now farming level %d (max energy %d).", p->level, p->maxEnergy);
        for (int c = 0; c < CROP_COUNT; c++)
            if (crop_info(c)->minLevel == p->level)
                game_msg(gs, "New seeds unlocked at the market: %s!", crop_info(c)->name);
    }
    if (p->level >= MAX_LEVEL) p->xp = 0;
}

/* ------------------------------------------------------------ progression */

void game_check_progress(GameState *gs)
{
    if (!gs->won && (gs->player.money >= WIN_MONEY || gs->player.level >= MAX_LEVEL)) {
        gs->won = true;
        char text[512];
        snprintf(text, sizeof text,
                 "You are now a MASTER FARMER!\n\n"
                 "Day %d   Money $%d   Level %d\n"
                 "Total earned: $%ld   Crops harvested: %d\n\n"
                 "Keep playing as long as you like (until day %d).",
                 gs->day, gs->player.money, gs->player.level,
                 gs->totalEarned, gs->totalHarvested, GAME_DAY_LIMIT);
        ui_popup(gs, " *** VICTORY *** ", text);
    }
}

static void check_game_over(GameState *gs)
{
    if (gs->day > GAME_DAY_LIMIT && !gs->gameOver) {
        gs->gameOver = true;
        char text[512];
        snprintf(text, sizeof text,
                 "Three years have passed on the farm.\n\n"
                 "%s\n\n"
                 "Final money: $%d   Level: %d\n"
                 "Total earned: $%ld   Crops harvested: %d",
                 gs->won ? "You retire as a celebrated MASTER FARMER!"
                         : "You didn't reach the Master Farmer goal this time.",
                 gs->player.money, gs->player.level, gs->totalEarned, gs->totalHarvested);
        ui_popup(gs, " GAME OVER ", text);
        gs->quit = true;
    }
}

/* ---------------------------------------------------------------- sleeping */

/* Random morning event. Writes a description to buf (empty = nothing). */
static void roll_event(GameState *gs, char *buf, size_t n)
{
    buf[0] = '\0';
    int r = rand() % 100;
    if (r < 12) {
        if (farm_crow_attack(&gs->farm))
            snprintf(buf, n, "Crows raided the field and ate a young crop!");
    } else if (r < 22) {
        int gift = 20 + rand() % 61;
        gs->player.money += gift;
        snprintf(buf, n, "A traveller left $%d as thanks for your hospitality.", gift);
    } else if (r < 30) {
        gs->festival = true;
        roll_prices(gs);
        snprintf(buf, n, "HARVEST FAIR! Market prices are up 25%% today.");
    } else if (r < 38) {
        int c = rand() % CROP_COUNT;
        while (crop_info(c)->minLevel > gs->player.level) c = rand() % CROP_COUNT;
        gs->inv.seeds[c] += 3;
        snprintf(buf, n, "A neighbour gifted you 3 %s seeds.", crop_info(c)->name);
    }
}

/*
 * End the day.  Order matters:
 *   1. crops grow based on today's watering
 *   2. the date, season and weather advance
 *   3. overnight rain waters everything; storms damage crops
 *   4. energy is restored, prices and events are rolled
 */
void game_sleep(GameState *gs, bool passedOut)
{
    Player *p = &gs->player;
    DayReport rep;
    char report[1200], extra[160];
    Season oldSeason = SEASON_OF_DAY(gs->day);

    bool inBed = abs(p->x - gs->farm.doorX) <= 3 && abs(p->y - gs->farm.doorY) <= 4;

    farm_new_day(&gs->farm, &rep);
    gs->day++;
    gs->minutes = START_MINUTES;
    gs->festival = false;
    Season season = SEASON_OF_DAY(gs->day);

    gs->weather.today = gs->weather.tomorrow;
    gs->weather.tomorrow = roll_weather(SEASON_OF_DAY(gs->day + 1));

    int frost = 0;
    if (season != oldSeason) frost = farm_season_frost(&gs->farm, season);

    if (gs->weather.today >= WEATHER_RAINY) {
        farm_apply_rain(&gs->farm);
        p->waterLeft = p->waterMax;                 /* rain fills the can */
    }
    if (gs->weather.today == WEATHER_STORMY) rep.destroyed += farm_storm_damage(&gs->farm);

    /* Energy. */
    int restore = passedOut ? 50 : (inBed ? 100 : 65);
    p->energy += p->maxEnergy * restore / 100;
    if (p->energy > p->maxEnergy) p->energy = p->maxEnergy;

    int fee = 0;
    if (passedOut) {
        gs->passouts++;
        fee = p->money / 10;
        if (fee > 200) fee = 200;
        p->money -= fee;
    }

    roll_prices(gs);
    roll_event(gs, extra, sizeof extra);
    if (extra[0] == '\0' && rep.destroyed == 0) extra[0] = '\0';
    rep.destroyed += 0;

    /* Morning report. */
    int planted, ripe;
    farm_count_crops(&gs->farm, &planted, &ripe);
    int len = snprintf(report, sizeof report, "Day %d  -  %s %d  (Year %d)\n\n",
                       gs->day, season_name(season), DAY_IN_SEASON(gs->day), YEAR_OF_DAY(gs->day));
    len += snprintf(report + len, sizeof report - (size_t)len, "Weather today: %s.   Tomorrow: %s.\n",
                    weather_name(gs->weather.today, season),
                    weather_name(gs->weather.tomorrow, SEASON_OF_DAY(gs->day + 1)));
    if (gs->weather.today >= WEATHER_RAINY)
        len += snprintf(report + len, sizeof report - (size_t)len, "The rain watered all your crops!\n");
    len += snprintf(report + len, sizeof report - (size_t)len, "\n");
    if (passedOut)
        len += snprintf(report + len, sizeof report - (size_t)len,
                        "You collapsed from exhaustion! A neighbour carried you home\n"
                        "and charged $%d. Energy restored only partly.\n", fee);
    else
        len += snprintf(report + len, sizeof report - (size_t)len, "You slept %s.\n",
                        inBed ? "soundly in your own bed" : "rough, out in the open");
    len += snprintf(report + len, sizeof report - (size_t)len,
                    "Crops grew: %d   Newly ripe: %d   Ripe now: %d\n", rep.grown, rep.newlyRipe, ripe);
    if (rep.withered)
        len += snprintf(report + len, sizeof report - (size_t)len,
                        "%d crop(s) withered from lack of water!\n", rep.withered);
    if (rep.destroyed)
        len += snprintf(report + len, sizeof report - (size_t)len,
                        "The storm destroyed %d crop(s)!\n", rep.destroyed);
    if (frost)
        len += snprintf(report + len, sizeof report - (size_t)len,
                        "A new season began: %d unsuited crop(s) died.\n", frost);
    if (extra[0])
        len += snprintf(report + len, sizeof report - (size_t)len, "\n%s\n", extra);
    if (DAY_IN_SEASON(gs->day) == DAYS_PER_SEASON)
        len += snprintf(report + len, sizeof report - (size_t)len,
                        "\nLast day of %s! Crops unfit for %s will die tomorrow.\n",
                        season_name(season), season_name(SEASON_OF_DAY(gs->day + 1)));

    game_msg(gs, "Day %d begins. %s. Energy %d/%d.", gs->day,
             weather_name(gs->weather.today, season), p->energy, p->maxEnergy);

    /* Autosave, then show the report. */
    bool saved = !gs->gameOver && gs->day <= GAME_DAY_LIMIT && save_game(gs, SAVE_PATH);
    if (saved) snprintf(report + len, sizeof report - (size_t)len, "\n(game autosaved)");
    ui_popup(gs, " GOOD MORNING ", report);
    check_game_over(gs);
}

/* ------------------------------------------------------------------ clock */

void game_advance_time(GameState *gs, int minutes)
{
    gs->minutes += minutes;
    if (gs->minutes >= PASSOUT_MINUTES) game_sleep(gs, true);
}

/* ---------------------------------------------------------------- actions */

static bool spend_energy(GameState *gs, int cost)
{
    if (gs->player.energy < cost) {
        game_msg(gs, "Too tired! Sleep with N, or buy an Energy Tonic at the market.");
        return false;
    }
    gs->player.energy -= cost;
    return true;
}

static Tile *facing_tile(GameState *gs)
{
    int tx, ty;
    player_face_target(&gs->player, &tx, &ty);
    return farm_tile(&gs->farm, tx, ty);
}

static void act_till(GameState *gs)
{
    gs->player.tool = TOOL_HOE;
    Tile *t = facing_tile(gs);
    if (!t) { game_msg(gs, "Nothing to till at the edge of the world."); return; }
    if (t->type == TILE_SOIL) { game_msg(gs, "That soil is already tilled."); return; }
    if (t->type != TILE_GRASS && t->type != TILE_FLOWER) { game_msg(gs, "You can't till that."); return; }
    if (!spend_energy(gs, COST_TILL)) return;
    farm_till(t);
    game_msg(gs, "You till the soil. (-%d energy)", COST_TILL);
    game_advance_time(gs, 20);
}

static void act_plant(GameState *gs)
{
    Player *p = &gs->player;
    p->tool = TOOL_SEEDS;
    Tile *t = facing_tile(gs);
    const CropInfo *ci = crop_info(p->seed);
    if (!t || t->type != TILE_SOIL) { game_msg(gs, "Till some soil first (X), then plant."); return; }
    if (t->crop != NO_CROP) { game_msg(gs, "Something is already growing here."); return; }
    if (gs->inv.seeds[p->seed] <= 0) { game_msg(gs, "No %s seeds left! Buy more at the market (B).", ci->name); return; }
    if (p->level < ci->minLevel) { game_msg(gs, "%s needs farming level %d.", ci->name, ci->minLevel); return; }
    Season s = SEASON_OF_DAY(gs->day);
    if (!crop_in_season(p->seed, s)) {
        char ss[24];
        crop_season_str(p->seed, ss, sizeof ss);
        game_msg(gs, "%s won't grow in %s (needs: %s).", ci->name, season_name(s), ss);
        return;
    }
    if (!spend_energy(gs, COST_PLANT)) return;
    farm_plant(t, p->seed);
    gs->inv.seeds[p->seed]--;
    int left = DAYS_PER_SEASON - DAY_IN_SEASON(gs->day);
    if (ci->growDays > left + 1 && !crop_in_season(p->seed, SEASON_OF_DAY(gs->day + left + 1)))
        game_msg(gs, "Planted %s. Warning: it may not ripen before the season ends!", ci->name);
    else
        game_msg(gs, "Planted %s. Water it daily; ripens in %d days.", ci->name, ci->growDays);
    game_advance_time(gs, 10);
}

static void act_water(GameState *gs)
{
    Player *p = &gs->player;
    p->tool = TOOL_CAN;
    Tile *t = facing_tile(gs);
    if (!t || t->type != TILE_SOIL) { game_msg(gs, "Water goes on tilled soil. (Refill at the pond with E.)"); return; }
    if (t->watered) { game_msg(gs, "Already watered today."); return; }
    if (t->crop == NO_CROP) { game_msg(gs, "Nothing is planted here yet."); return; }
    if (p->waterLeft <= 0) { game_msg(gs, "Your can is empty! Face the pond and press E to refill."); return; }
    if (!spend_energy(gs, COST_WATER)) return;
    farm_water(t);
    p->waterLeft--;
    game_msg(gs, "Watered. Can: %d/%d.", p->waterLeft, p->waterMax);
    game_advance_time(gs, 10);
}

static void act_harvest(GameState *gs)
{
    Player *p = &gs->player;
    p->tool = TOOL_SICKLE;
    Tile *t = facing_tile(gs);
    if (!t || t->type != TILE_SOIL || t->crop == NO_CROP) { game_msg(gs, "Nothing to harvest there."); return; }
    if (t->withered) {
        if (!spend_energy(gs, 1)) return;
        farm_clear_dead(t);
        game_msg(gs, "You clear away the dead plant.");
        game_advance_time(gs, 5);
        return;
    }
    if (!crop_ready(t)) {
        game_msg(gs, "%s isn't ripe: %d more watered day(s).", crop_info(t->crop)->name, crop_days_left(t));
        return;
    }
    if (!spend_energy(gs, COST_HARVEST)) return;
    int crop = farm_harvest(t);
    int yield = 1;
    if (rand() % 100 < p->level * 3) yield = 2;           /* skill bonus */
    gs->inv.crops[crop] += yield;
    gs->totalHarvested += yield;
    if (yield == 2) game_msg(gs, "Bonus yield! You harvested 2 %s.", crop_info(crop)->name);
    else game_msg(gs, "You harvested a %s. (+%d XP)", crop_info(crop)->name, crop_info(crop)->xp);
    game_gain_xp(gs, crop_info(crop)->xp);
    game_check_progress(gs);
    game_advance_time(gs, 15);
}

static void act_fertilize(GameState *gs)
{
    gs->player.tool = TOOL_FERT;
    Tile *t = facing_tile(gs);
    if (!t || t->type != TILE_SOIL || t->crop == NO_CROP || t->withered) { game_msg(gs, "Fertilizer needs a growing crop."); return; }
    if (crop_ready(t)) { game_msg(gs, "It's already ripe!"); return; }
    if (gs->inv.fertilizer <= 0) { game_msg(gs, "No fertilizer. Buy some at the market."); return; }
    if (!spend_energy(gs, COST_FERT)) return;
    farm_fertilize(t);
    gs->inv.fertilizer--;
    game_msg(gs, "Fertilized! %s has %d day(s) to go.", crop_info(t->crop)->name, crop_days_left(t));
    game_advance_time(gs, 10);
}

static void act_chop(GameState *gs, Tile *t)
{
    if (!spend_energy(gs, COST_CHOP)) return;
    farm_chop(t);
    int wood = 1 + rand() % 2;
    gs->inv.wood += wood;
    game_msg(gs, "Chop chop! +%d wood (sell it at the market).", wood);
    game_gain_xp(gs, 1);
    game_advance_time(gs, 30);
}

static bool near_tile(const GameState *gs, TileType type)
{
    for (int dy = -1; dy <= 1; dy++)
        for (int dx = -1; dx <= 1; dx++) {
            const Tile *t = farm_tile_c(&gs->farm, gs->player.x + dx, gs->player.y + dy);
            if (t && t->type == type) return true;
        }
    return false;
}

static void open_shop(GameState *gs)
{
    if (!near_tile(gs, TILE_SHOP)) { game_msg(gs, "Stand next to the market ($) to trade."); return; }
    shop_run(gs);
}

static void open_chest(GameState *gs)
{
    if (!near_tile(gs, TILE_CHEST)) { game_msg(gs, "You need to be next to the chest (C)."); return; }
    chest_run(gs);
}

static void ask_sleep(GameState *gs)
{
    if (ui_confirm(gs, "End the day and go to sleep?")) game_sleep(gs, false);
}

/* E key: interact with what's in front of you, otherwise use the tool. */
static void act_interact(GameState *gs)
{
    Player *p = &gs->player;
    Tile *t = facing_tile(gs);
    if (!t) return;
    switch ((TileType)t->type) {
    case TILE_DOOR:  ask_sleep(gs); return;
    case TILE_SHOP:  open_shop(gs); return;
    case TILE_CHEST: open_chest(gs); return;
    case TILE_TREE:  act_chop(gs, t); return;
    case TILE_WATER:
        if (p->waterLeft >= p->waterMax) game_msg(gs, "Your can is already full.");
        else {
            p->waterLeft = p->waterMax;
            game_msg(gs, "You refill the watering can (%d/%d).", p->waterLeft, p->waterMax);
            game_advance_time(gs, 10);
        }
        return;
    default: break;
    }
    switch (p->tool) {
    case TOOL_HOE:    act_till(gs); break;
    case TOOL_CAN:    act_water(gs); break;
    case TOOL_SEEDS:  act_plant(gs); break;
    case TOOL_SICKLE: act_harvest(gs); break;
    case TOOL_FERT:   act_fertilize(gs); break;
    default: break;
    }
}

static void do_move(GameState *gs, Direction d)
{
    if (player_step(&gs->player, &gs->farm, d)) {
        game_advance_time(gs, 2);
        return;
    }
    /* Blocked: give a hint about what we bumped into. */
    const Tile *t = facing_tile(gs);
    if (!t) return;
    switch ((TileType)t->type) {
    case TILE_DOOR:  game_msg(gs, "Your front door. Press E to go to bed."); break;
    case TILE_SHOP:  game_msg(gs, "The market! Press E (or B) to trade."); break;
    case TILE_CHEST: game_msg(gs, "Your storage chest. Press E (or C) to open it."); break;
    case TILE_WATER: game_msg(gs, "Water. Press E to refill your watering can."); break;
    case TILE_TREE:  game_msg(gs, "A tree. Press E to chop it for wood."); break;
    default: break;
    }
}

/* ----------------------------------------------------------- key handling */

static void pause_menu(GameState *gs)
{
    for (;;) {
        int choice = ui_pause_menu(gs);
        if (choice == PAUSE_RESUME) return;
        if (choice == PAUSE_SAVE) {
            if (save_game(gs, SAVE_PATH)) game_msg(gs, "Game saved to %s.", SAVE_PATH);
            else game_msg(gs, "Could not write the save file!");
            return;
        }
        if (choice == PAUSE_LOAD) {
            if (!save_exists(SAVE_PATH)) { game_msg(gs, "No save file found."); return; }
            if (ui_confirm(gs, "Load the saved game? Unsaved progress is lost.")) {
                if (load_game(gs, SAVE_PATH)) game_msg(gs, "Game loaded. Welcome back!");
                else game_msg(gs, "That save file could not be read.");
            }
            return;
        }
        if (choice == PAUSE_HELP) { ui_help(gs); continue; }
        if (choice == PAUSE_QUIT) {
            if (ui_confirm(gs, "Quit to the main menu? Unsaved progress is lost.")) gs->quit = true;
            return;
        }
    }
}

void game_handle_key(GameState *gs, int key)
{
    if (key >= 'A' && key <= 'Z') key += 32;
    Player *p = &gs->player;

    switch (key) {
    case 'w': case KEY_UP:    do_move(gs, DIR_UP); break;
    case 's': case KEY_DOWN:  do_move(gs, DIR_DOWN); break;
    case 'a': case KEY_LEFT:  do_move(gs, DIR_LEFT); break;
    case 'd': case KEY_RIGHT: do_move(gs, DIR_RIGHT); break;
    case 'x': act_till(gs); break;
    case 'p': act_plant(gs); break;
    case 'r': act_water(gs); break;
    case 'h': act_harvest(gs); break;
    case 'f': act_fertilize(gs); break;
    case 'e': case ' ': act_interact(gs); break;
    case 't':
        p->tool = (ToolType)((p->tool + 1) % TOOL_COUNT);
        game_msg(gs, "Tool: %s. Press E to use it on the tile you face.", tool_name(p->tool));
        break;
    case 'g':
        p->seed = (p->seed + 1) % CROP_COUNT;
        p->tool = TOOL_SEEDS;
        game_msg(gs, "Seed: %s (you have %d).", crop_info(p->seed)->name, gs->inv.seeds[p->seed]);
        break;
    case '1': case '2': case '3': case '4': case '5': case '6':
        p->seed = key - '1';
        p->tool = TOOL_SEEDS;
        game_msg(gs, "Seed: %s (you have %d).", crop_info(p->seed)->name, gs->inv.seeds[p->seed]);
        break;
    case 'b': open_shop(gs); break;
    case 'c': open_chest(gs); break;
    case 'i': ui_inventory(gs); break;
    case 'n': ask_sleep(gs); break;
    case '?': case '/': ui_help(gs); break;
    case KEY_ESC: pause_menu(gs); break;
    case 'q':
        if (ui_confirm(gs, "Quit to the main menu? Unsaved progress is lost.")) gs->quit = true;
        break;
    default: break;
    }
}

/* -------------------------------------------------------------- main loop */

void game_run(GameState *gs)
{
    ui_clear_screen();
    while (!gs->quit) {
        ui_begin();
        ui_render_game(gs);
        ui_flush();

        int key = ui_get_key(450);            /* timeout drives the animation */
        if (key == KEY_EOF) break;
        if (key == KEY_NONE) {
            gs->frame++;
            update_animals(gs);
            continue;
        }
        gs->frame++;
        game_handle_key(gs, key);
        game_check_progress(gs);
    }
}
