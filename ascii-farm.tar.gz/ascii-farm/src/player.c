/* player.c - the farmer. */
#include "player.h"
#include "farm.h"

void player_init(Player *p, int x, int y)
{
    p->x = x;
    p->y = y;
    p->facing = DIR_DOWN;
    p->level = 1;
    p->xp = 0;
    p->maxEnergy = player_max_energy(1);
    p->energy = p->maxEnergy;
    p->money = 150;
    p->tool = TOOL_HOE;
    p->seed = CROP_WHEAT;
    p->waterMax = 15;
    p->waterLeft = p->waterMax;
    p->canUpgrades = 0;
}

static const int DX[4] = { 0, 0, -1, 1 };
static const int DY[4] = { -1, 1, 0, 0 };

/* Turn to face d, then walk if the destination is free. */
bool player_step(Player *p, const Farm *f, Direction d)
{
    p->facing = d;
    int nx = p->x + DX[d];
    int ny = p->y + DY[d];
    if (!farm_walkable(f, nx, ny)) return false;
    p->x = nx;
    p->y = ny;
    return true;
}

/* The tile the player is facing (may be out of bounds). */
void player_face_target(const Player *p, int *tx, int *ty)
{
    *tx = p->x + DX[p->facing];
    *ty = p->y + DY[p->facing];
}

int player_xp_needed(int level)  { return 40 * level; }
int player_max_energy(int level) { return 100 + 10 * (level - 1); }

const char *tool_name(ToolType t)
{
    static const char *names[TOOL_COUNT] = {
        "Hoe", "Watering Can", "Seed Bag", "Sickle", "Fertilizer"
    };
    return (t >= 0 && t < TOOL_COUNT) ? names[t] : "?";
}

const char *dir_name(Direction d)
{
    static const char *names[4] = { "North", "South", "West", "East" };
    return names[d];
}
