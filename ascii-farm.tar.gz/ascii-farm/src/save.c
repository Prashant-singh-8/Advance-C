/*
 * save.c - binary save files.
 *
 * File layout:  [SaveHeader][GameState]
 * The header lets us reject files from other versions / other builds
 * instead of loading garbage.
 */
#include <stdio.h>
#include <string.h>
#include "save.h"

#define SAVE_MAGIC "ASCIIFRM"
#define SAVE_VERSION 1u

typedef struct {
    char magic[8];
    unsigned version;
    unsigned long stateSize;
} SaveHeader;

bool save_game(const GameState *gs, const char *path)
{
    FILE *fp = fopen(path, "wb");
    if (!fp) return false;

    SaveHeader h;
    memset(&h, 0, sizeof h);
    memcpy(h.magic, SAVE_MAGIC, 8);
    h.version = SAVE_VERSION;
    h.stateSize = sizeof(GameState);

    bool ok = fwrite(&h, sizeof h, 1, fp) == 1 &&
              fwrite(gs, sizeof *gs, 1, fp) == 1;
    if (fclose(fp) != 0) ok = false;
    return ok;
}

bool load_game(GameState *gs, const char *path)
{
    FILE *fp = fopen(path, "rb");
    if (!fp) return false;

    SaveHeader h;
    bool ok = fread(&h, sizeof h, 1, fp) == 1 &&
              memcmp(h.magic, SAVE_MAGIC, 8) == 0 &&
              h.version == SAVE_VERSION &&
              h.stateSize == sizeof(GameState);
    if (ok) {
        /* Read into a temporary so a truncated file cannot corrupt gs. */
        static GameState tmp;
        if (fread(&tmp, sizeof tmp, 1, fp) == 1) {
            *gs = tmp;
            gs->quit = false;
        } else {
            ok = false;
        }
    }
    fclose(fp);
    return ok;
}

bool save_exists(const char *path)
{
    FILE *fp = fopen(path, "rb");
    if (!fp) return false;
    fclose(fp);
    return true;
}
