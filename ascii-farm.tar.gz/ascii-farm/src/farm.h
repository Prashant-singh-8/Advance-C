/* farm.h - the world map and everything that happens to tiles. */
#ifndef FARM_H
#define FARM_H

#include "types.h"

/* Field fence rectangle (perimeter coordinates); interior is plantable. */
#define FIELD_X0 22
#define FIELD_Y0 14
#define FIELD_X1 52
#define FIELD_Y1 30

/* What happened overnight, for the morning report. */
typedef struct {
    int grown;       /* crops that advanced a growth day   */
    int newlyRipe;   /* crops that became ready            */
    int withered;    /* crops that died of thirst          */
    int destroyed;   /* crops lost to storms / crows       */
} DayReport;

void  farm_generate(Farm *f);
bool  farm_in_bounds(int x, int y);
Tile *farm_tile(Farm *f, int x, int y);
const Tile *farm_tile_c(const Farm *f, int x, int y);
bool  farm_walkable(const Farm *f, int x, int y);
const char *farm_area_name(int x, int y);

/* Farming actions on a single tile. Each returns true on success. */
bool  farm_till(Tile *t);
bool  farm_plant(Tile *t, int crop);
bool  farm_water(Tile *t);
int   farm_harvest(Tile *t);        /* returns crop type or NO_CROP */
void  farm_clear_dead(Tile *t);
bool  farm_fertilize(Tile *t);
void  farm_chop(Tile *t);

/* Daily processing. */
void  farm_new_day(Farm *f, DayReport *rep);   /* grow crops, reset water */
void  farm_apply_rain(Farm *f);                /* water every soil tile   */
int   farm_storm_damage(Farm *f);              /* returns crops destroyed */
int   farm_season_frost(Farm *f, Season s);    /* wither unsuited crops   */
int   farm_crow_attack(Farm *f);               /* destroy one random crop */
void  farm_count_crops(const Farm *f, int *planted, int *ripe);

#endif
