/*
 * ui.h - everything that touches the terminal.
 *
 * Drawing works on a single output buffer: call ui_begin(), append drawing
 * (ui_render_game / ui_box / ui_text ...), then ui_flush() once. That makes
 * each frame one write() call, so there is no flicker.
 */
#ifndef UI_H
#define UI_H

#include "types.h"

/* ---- ANSI colour helpers (usable inside printf formats) ------------------ */
#define C_RESET   "\x1b[0m"
#define C_BOLD    "\x1b[1m"
#define C_DIM     "\x1b[2m"
#define C_RED     "\x1b[31m"
#define C_GREEN   "\x1b[32m"
#define C_YELLOW  "\x1b[33m"
#define C_BLUE    "\x1b[34m"
#define C_MAGENTA "\x1b[35m"
#define C_CYAN    "\x1b[36m"
#define C_WHITE   "\x1b[37m"
#define C_BYELLOW "\x1b[1;33m"
#define C_BGREEN  "\x1b[1;32m"
#define C_BRED    "\x1b[1;31m"
#define C_BCYAN   "\x1b[1;36m"
#define C_BWHITE  "\x1b[1;37m"

/* ---- Keys ---------------------------------------------------------------- */
#define KEY_NONE  0
#define KEY_EOF   (-1)
#define KEY_ESC   27
#define KEY_UP    1001
#define KEY_DOWN  1002
#define KEY_RIGHT 1003
#define KEY_LEFT  1004

/* ---- Main menu / pause menu results -------------------------------------- */
enum { MENU_NEW, MENU_CONTINUE, MENU_HELP, MENU_QUIT };
enum { PAUSE_RESUME, PAUSE_SAVE, PAUSE_LOAD, PAUSE_HELP, PAUSE_QUIT };

/* ---- Terminal lifecycle & input ------------------------------------------ */
void ui_init(void);
void ui_shutdown(void);
bool ui_terminal_big_enough(void);
int  ui_get_key(int timeout_ms);     /* -1 = block; KEY_NONE on timeout */

/* ---- Frame buffer -------------------------------------------------------- */
void ui_begin(void);
void ui_flush(void);
void ui_clear_screen(void);
void ui_text(int row, int col, const char *fmt, ...);        /* 1-based */
void ui_box(int row, int col, int w, int h, const char *title);

/* ---- Screens ------------------------------------------------------------- */
void ui_render_game(const GameState *gs);
int  ui_main_menu(bool hasSave);
int  ui_pause_menu(const GameState *gs);
void ui_help(const GameState *gs);                  /* gs may be NULL */
void ui_inventory(const GameState *gs);
void ui_popup(const GameState *gs, const char *title, const char *text);
bool ui_confirm(const GameState *gs, const char *question);

#endif
