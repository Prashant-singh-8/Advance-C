/* crop.c - crop table and growth helpers. */
#include <stdio.h>
#include <string.h>
#include "crop.h"

#define SP SEASON_BIT(SEASON_SPRING)
#define SU SEASON_BIT(SEASON_SUMMER)
#define AU SEASON_BIT(SEASON_AUTUMN)
#define WI SEASON_BIT(SEASON_WINTER)

/*
 * To add a crop: add an enum value in types.h (before CROP_COUNT) and one
 * row here.  Everything else (shop, inventory, UI) picks it up automatically.
 *
 *  name      seed sell grow regrow lvl seasons        xp color
 */
static const CropInfo TABLE[CROP_COUNT] = {
    { "Wheat",    10,  24, 3, 0, 1, SP | SU | AU,  6, "33"       },
    { "Carrot",   15,  38, 4, 0, 1, SP | AU | WI,  8, "38;5;208" },
    { "Potato",   25,  62, 5, 0, 2, SP | AU | WI, 12, "37"       },
    { "Tomato",   35,  55, 5, 2, 3, SU | AU,      12, "1;31"     },
    { "Corn",     50, 110, 7, 3, 4, SU | AU,      18, "1;33"     },
    { "Pumpkin",  80, 230, 9, 0, 5, SU | AU,      30, "38;5;166" },
};

const CropInfo *crop_info(int type)
{
    if (type < 0 || type >= CROP_COUNT) type = 0;
    return &TABLE[type];
}

bool crop_in_season(int type, Season s)
{
    return (crop_info(type)->seasons & SEASON_BIT(s)) != 0;
}

void crop_season_str(int type, char *out, size_t n)
{
    static const char *abbr[4] = { "Sp", "Su", "Au", "Wi" };
    out[0] = '\0';
    for (int s = 0; s < 4; s++) {
        if (crop_in_season(type, (Season)s)) {
            size_t len = strlen(out);
            snprintf(out + len, n - len, "%s%s", len ? " " : "", abbr[s]);
        }
    }
}

bool crop_ready(const Tile *t)
{
    return t->crop != NO_CROP && !t->withered &&
           t->growth >= crop_info(t->crop)->growDays;
}

int crop_stage(const Tile *t)
{
    if (t->crop == NO_CROP) return 0;
    const CropInfo *ci = crop_info(t->crop);
    if (t->growth >= ci->growDays) return 3;
    return (t->growth * 3) / ci->growDays;      /* 0, 1 or 2 */
}

char crop_glyph(const Tile *t)
{
    static const char glyphs[4] = { 's', 'y', 'Y', 'F' };
    if (t->withered) return 'x';
    return glyphs[crop_stage(t)];
}

int crop_days_left(const Tile *t)
{
    if (t->crop == NO_CROP) return 0;
    int left = crop_info(t->crop)->growDays - t->growth;
    return left < 0 ? 0 : left;
}
