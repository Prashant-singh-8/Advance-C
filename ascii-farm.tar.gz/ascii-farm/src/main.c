/*
 * main.c - program entry: title menu, then hand over to game_run().
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "game.h"
#include "save.h"
#include "ui.h"

static GameState g_state;      /* ~100 KB: keep it off the stack */

static void wait_for_big_terminal(void)
{
    while (!ui_terminal_big_enough()) {
        ui_popup(NULL, " TERMINAL TOO SMALL ",
                 "Please enlarge the window to at least 80 x 28.\n"
                 "Then press any key.");
    }
}

int main(void)
{
    srand((unsigned)time(NULL));
    ui_init();
    wait_for_big_terminal();

    for (;;) {
        int choice = ui_main_menu(save_exists(SAVE_PATH));

        if (choice == MENU_QUIT) break;

        if (choice == MENU_HELP) {
            ui_help(NULL);
            continue;
        }
        if (choice == MENU_CONTINUE) {
            if (!load_game(&g_state, SAVE_PATH)) {
                ui_popup(NULL, " LOAD FAILED ", "The save file is missing or from another version.");
                continue;
            }
            game_msg(&g_state, "Game loaded. Welcome back to the farm!");
        } else {
            game_new(&g_state);
        }
        game_run(&g_state);
        if (g_state.quit && !g_state.gameOver && !ui_terminal_big_enough()) break;
    }

    ui_shutdown();
    puts("Thanks for playing ASCII Farming Simulator!");
    return 0;
}
