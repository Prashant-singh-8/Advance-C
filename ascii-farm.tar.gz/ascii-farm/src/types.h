/*
 * types.h - shared constants, enums and data structures.
 *
 * Every struct stored in GameState is "plain old data" (no pointers), which is
 * what lets save.c write the whole game to disk with a single fwrite().
 */
#ifndef TYPES_H
#define TYPES_H

#include <stdbool.h>
#include <stdint.h>

/* ---- World / screen dimensions ------------------------------------------ */
#define MAP_W 80
#define MAP_H 40
#define VIEW_W 52            /* map viewport (camera) width in tiles  */
#define VIEW_H 15            /* map viewport height in tiles          */
#define PANEL_W 24           /* side-panel width in characters        */
#define SCREEN_W 79          /* total UI width                        */
#define SCREEN_H 28          /* total UI height                       */

/* ---- Game rules ---------------------------------------------------------- */
#define MSG_COUNT 3          /* lines in the message log              */
#define MSG_LEN 160
#define DAYS_PER_SEASON 7
#define DAYS_PER_YEAR 28
#define GAME_DAY_LIMIT 84    /* 3 years to become a Master Farmer     */
#define WIN_MONEY 10000
#define MAX_LEVEL 10
#define START_MINUTES (6 * 60)      /* you wake at 06:00              */
#define PASSOUT_MINUTES (26 * 60)   /* you collapse at 02:00          */
#define MAX_ANIMALS 4
#define MAX_CAN_UPGRADES 3
#define SAVE_PATH "farm_save.dat"

/* ---- Enums --------------------------------------------------------------- */
typedef enum {
    CROP_WHEAT = 0, CROP_CARROT, CROP_POTATO,
    CROP_TOMATO, CROP_CORN, CROP_PUMPKIN,
    CROP_COUNT
} CropType;
#define NO_CROP (-1)

typedef enum { SEASON_SPRING, SEASON_SUMMER, SEASON_AUTUMN, SEASON_WINTER } Season;

typedef enum { WEATHER_SUNNY, WEATHER_CLOUDY, WEATHER_RAINY, WEATHER_STORMY } WeatherType;

typedef enum {
    TILE_GRASS, TILE_PATH, TILE_FENCE, TILE_WATER, TILE_TREE, TILE_SOIL,
    TILE_HOUSE, TILE_DOOR, TILE_SHOP, TILE_CHEST, TILE_ROCK, TILE_FLOWER
} TileType;

typedef enum { TOOL_HOE, TOOL_CAN, TOOL_SEEDS, TOOL_SICKLE, TOOL_FERT, TOOL_COUNT } ToolType;

typedef enum { DIR_UP, DIR_DOWN, DIR_LEFT, DIR_RIGHT } Direction;

/* ---- Structs ------------------------------------------------------------- */

/* One square of the map. Tilled soil can also hold a growing crop. */
typedef struct {
    uint8_t type;      /* TileType                                         */
    char    ch;        /* fixed glyph for buildings (roof, wall, sign...)  */
    int8_t  crop;      /* CropType or NO_CROP                              */
    uint8_t growth;    /* days the crop has grown                          */
    uint8_t dry;       /* consecutive days without water                   */
    uint8_t watered;   /* 1 if watered since the last night                */
    uint8_t withered;  /* 1 if the crop died                               */
} Tile;

typedef struct {
    Tile tiles[MAP_H][MAP_W];
    int doorX, doorY;  /* where the bed (house door) is */
} Farm;

typedef struct {
    int x, y;
    Direction facing;
    int energy, maxEnergy;
    int money;
    int level, xp;
    ToolType tool;
    int seed;            /* selected CropType for planting */
    int waterLeft, waterMax;
    int canUpgrades;
} Player;

typedef struct {
    int seeds[CROP_COUNT];
    int crops[CROP_COUNT];   /* harvested produce in the backpack */
    int chest[CROP_COUNT];   /* produce stored in the chest       */
    int wood;
    int fertilizer;
} Inventory;

typedef struct {
    WeatherType today;
    WeatherType tomorrow;    /* the forecast */
} Weather;

typedef struct {
    int x, y, homeX, homeY;
    char glyph;
} Animal;

typedef struct {
    Farm farm;
    Player player;
    Inventory inv;
    Weather weather;
    int day;                       /* starts at 1                        */
    int minutes;                   /* minutes since midnight (>=1440 = after midnight) */
    int priceMod[CROP_COUNT];      /* today's market price in percent    */
    bool festival;                 /* harvest fair today (+25% prices)   */
    char msg[MSG_COUNT][MSG_LEN];  /* message log, newest last           */
    Animal animals[MAX_ANIMALS];
    unsigned long frame;           /* animation counter (not gameplay)   */
    bool won;
    bool gameOver;
    bool quit;
    long totalEarned;
    int totalHarvested;
    int passouts;
} GameState;

/* ---- Small helpers ------------------------------------------------------- */
#define SEASON_OF_DAY(d) ((Season)((((d) - 1) / DAYS_PER_SEASON) % 4))
#define DAY_IN_SEASON(d) ((((d) - 1) % DAYS_PER_SEASON) + 1)
#define YEAR_OF_DAY(d)   ((((d) - 1) / DAYS_PER_YEAR) + 1)
#define SEASON_BIT(s)    (1u << (s))

#endif /* TYPES_H */
