/* inventory.c - backpack helpers and the storage-chest menu. */
#include <string.h>
#include "inventory.h"
#include "crop.h"
#include "ui.h"

void inv_init(Inventory *inv)
{
    memset(inv, 0, sizeof *inv);
}

int inv_total_crops(const Inventory *inv)
{
    int n = 0;
    for (int i = 0; i < CROP_COUNT; i++) n += inv->crops[i];
    return n;
}

int inv_total_seeds(const Inventory *inv)
{
    int n = 0;
    for (int i = 0; i < CROP_COUNT; i++) n += inv->seeds[i];
    return n;
}

int inv_chest_total(const Inventory *inv)
{
    int n = 0;
    for (int i = 0; i < CROP_COUNT; i++) n += inv->chest[i];
    return n;
}

void inv_deposit_all(Inventory *inv)
{
    for (int i = 0; i < CROP_COUNT; i++) {
        inv->chest[i] += inv->crops[i];
        inv->crops[i] = 0;
    }
}

void inv_withdraw_all(Inventory *inv)
{
    for (int i = 0; i < CROP_COUNT; i++) {
        inv->crops[i] += inv->chest[i];
        inv->chest[i] = 0;
    }
}

/* ------------------------------------------------------------ chest menu */

void chest_run(GameState *gs)
{
    Inventory *inv = &gs->inv;
    char note[96] = "Store produce here to keep it safe for later.";

    for (;;) {
        ui_begin();
        ui_render_game(gs);
        ui_box(5, 12, 56, 18, " STORAGE CHEST ");
        ui_text(7, 15, C_BWHITE "     Crop        Backpack     Chest" C_RESET);
        for (int c = 0; c < CROP_COUNT; c++) {
            ui_text(8 + c, 15, " %d) %-10s %7d %10d",
                    c + 1, crop_info(c)->name, inv->crops[c], inv->chest[c]);
        }
        ui_text(15, 15, "    Totals:     %7d %10d",
                inv_total_crops(inv), inv_chest_total(inv));
        ui_text(17, 15, C_BYELLOW "%s" C_RESET, note);
        ui_text(19, 15, "[1-6] Move one crop type   [D] Deposit all");
        ui_text(20, 15, "[W] Withdraw all           [Esc] Close");
        ui_flush();

        int k = ui_get_key(-1);
        if (k == KEY_EOF) { gs->quit = true; return; }
        if (k == KEY_NONE) continue;
        if (k < 256) k = (k >= 'A' && k <= 'Z') ? k + 32 : k;

        if (k == KEY_ESC || k == 'q' || k == 'c') return;
        if (k == 'd') {
            inv_deposit_all(inv);
            strcpy(note, "Deposited all produce.");
        } else if (k == 'w') {
            inv_withdraw_all(inv);
            strcpy(note, "Took everything out of the chest.");
        } else if (k >= '1' && k <= '0' + CROP_COUNT) {
            int c = k - '1';
            if (inv->crops[c] > 0) {
                inv->chest[c] += inv->crops[c];
                inv->crops[c] = 0;
                strcpy(note, "Stored it.");
            } else if (inv->chest[c] > 0) {
                inv->crops[c] += inv->chest[c];
                inv->chest[c] = 0;
                strcpy(note, "Took it out.");
            } else {
                strcpy(note, "You have none of that.");
            }
        }
    }
}
