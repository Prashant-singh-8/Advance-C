/* crop.h - static crop data table and growth-stage helpers. */
#ifndef CROP_H
#define CROP_H

#include "types.h"

typedef struct {
    const char *name;
    int seedPrice;
    int sellPrice;
    int growDays;      /* days of watering needed to ripen              */
    int regrowDays;    /* >0: after harvest, ripens again in this time  */
    int minLevel;      /* farming level required to plant               */
    unsigned seasons;  /* bit mask of SEASON_BIT()s the crop can grow in */
    int xp;            /* farming XP per harvest                        */
    const char *color; /* ANSI SGR parameters, e.g. "1;33"              */
} CropInfo;

const CropInfo *crop_info(int type);
bool  crop_in_season(int type, Season s);
void  crop_season_str(int type, char *out, size_t n);   /* "Sp Su Au" */
int   crop_stage(const Tile *t);          /* 0..2 growing, 3 = ripe     */
bool  crop_ready(const Tile *t);
char  crop_glyph(const Tile *t);          /* s y Y F x                  */
int   crop_days_left(const Tile *t);

#endif
