/* shop.h - the market: buy seeds & supplies, sell produce. */
#ifndef SHOP_H
#define SHOP_H

#include "types.h"

int  shop_sell_price(const GameState *gs, int crop);   /* today's price */
void shop_run(GameState *gs);                          /* modal shop UI */

#endif
