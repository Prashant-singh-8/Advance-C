/*
 * shop.c - the market.
 *
 * Buy tab : keys 1-6 seeds, 7 fertilizer, 8 energy tonic, 9 watering-can upgrade.
 * Sell tab: keys 1-6 produce, 7 wood, A sells everything.
 * Prices of produce wobble daily (GameState.priceMod); a festival adds +25%.
 */
#include <stdio.h>
#include <string.h>
#include "shop.h"
#include "crop.h"
#include "game.h"
#include "ui.h"

#define WOOD_PRICE 8
#define FERT_PRICE 20
#define TONIC_PRICE 45
#define CAN_BASE_PRICE 150

int shop_sell_price(const GameState *gs, int crop)
{
    if (crop == CROP_COUNT) return WOOD_PRICE;       /* wood: fixed price */
    return crop_info(crop)->sellPrice * gs->priceMod[crop] / 100;
}

static int can_upgrade_price(const Player *p)
{
    return CAN_BASE_PRICE + 100 * p->canUpgrades;
}

/* Spend money if possible. */
static bool pay(Player *p, int cost)
{
    if (p->money < cost) return false;
    p->money -= cost;
    return true;
}

static void buy(GameState *gs, int idx, int qty, char *note, size_t n)
{
    Player *p = &gs->player;
    Inventory *inv = &gs->inv;

    if (idx >= 1 && idx <= CROP_COUNT) {                         /* seeds */
        int c = idx - 1;
        const CropInfo *ci = crop_info(c);
        if (p->level < ci->minLevel) {
            snprintf(note, n, "%s seeds need farming level %d.", ci->name, ci->minLevel);
            return;
        }
        int afford = p->money / ci->seedPrice;
        if (afford <= 0) { snprintf(note, n, "Not enough money for %s seeds.", ci->name); return; }
        if (qty > afford) qty = afford;
        pay(p, qty * ci->seedPrice);
        inv->seeds[c] += qty;
        snprintf(note, n, "Bought %d %s seed%s for $%d.", qty, ci->name,
                 qty == 1 ? "" : "s", qty * ci->seedPrice);
    } else if (idx == 7) {                                      /* fertilizer */
        int afford = p->money / FERT_PRICE;
        if (afford <= 0) { snprintf(note, n, "Not enough money for fertilizer."); return; }
        if (qty > afford) qty = afford;
        pay(p, qty * FERT_PRICE);
        inv->fertilizer += qty;
        snprintf(note, n, "Bought %d fertilizer for $%d.", qty, qty * FERT_PRICE);
    } else if (idx == 8) {                                      /* tonic */
        if (p->energy >= p->maxEnergy) { snprintf(note, n, "You're already full of energy!"); return; }
        if (!pay(p, TONIC_PRICE)) { snprintf(note, n, "Not enough money for a tonic."); return; }
        p->energy += 50;
        if (p->energy > p->maxEnergy) p->energy = p->maxEnergy;
        snprintf(note, n, "Glug glug! +50 energy.");
    } else if (idx == 9) {                                      /* can upgrade */
        if (p->canUpgrades >= MAX_CAN_UPGRADES) { snprintf(note, n, "Your watering can is fully upgraded."); return; }
        int cost = can_upgrade_price(p);
        if (!pay(p, cost)) { snprintf(note, n, "Upgrade costs $%d.", cost); return; }
        p->canUpgrades++;
        p->waterMax += 10;
        p->waterLeft = p->waterMax;
        snprintf(note, n, "Watering can now holds %d!", p->waterMax);
    }
}

/* Sell up to qty of item idx (1-6 crops, 7 wood). Returns money earned. */
static int sell_item(GameState *gs, int idx, int qty)
{
    Inventory *inv = &gs->inv;
    int *stock;
    int price;
    if (idx >= 1 && idx <= CROP_COUNT) {
        stock = &inv->crops[idx - 1];
        price = shop_sell_price(gs, idx - 1);
    } else {
        stock = &inv->wood;
        price = WOOD_PRICE;
    }
    if (qty > *stock) qty = *stock;
    if (qty <= 0) return 0;
    *stock -= qty;
    int earned = qty * price;
    gs->player.money += earned;
    gs->totalEarned += earned;
    return earned;
}

static int sell_value_all(const GameState *gs)
{
    int total = gs->inv.wood * WOOD_PRICE;
    for (int c = 0; c < CROP_COUNT; c++)
        total += gs->inv.crops[c] * shop_sell_price(gs, c);
    return total;
}

static void draw_buy(const GameState *gs, int qty)
{
    const Player *p = &gs->player;
    char seasons[24];
    ui_text(7, 10, C_BWHITE "  #  Item             Price  Lv  Seasons    Grow  Have" C_RESET);
    for (int c = 0; c < CROP_COUNT; c++) {
        const CropInfo *ci = crop_info(c);
        crop_season_str(c, seasons, sizeof seasons);
        bool locked = p->level < ci->minLevel;
        ui_text(8 + c, 10, "%s %d) %-10s seed  $%-4d %2d  %-9s  %2dd   x%d%s",
                locked ? C_DIM : "", c + 1, ci->name, ci->seedPrice, ci->minLevel,
                seasons, ci->growDays, gs->inv.seeds[c], C_RESET);
    }
    ui_text(14, 10, " 7) Fertilizer       $%-4d  -  +1 growth day   x%d", FERT_PRICE, gs->inv.fertilizer);
    ui_text(15, 10, " 8) Energy Tonic     $%-4d  -  +50 energy", TONIC_PRICE);
    if (p->canUpgrades < MAX_CAN_UPGRADES)
        ui_text(16, 10, " 9) Bigger Can       $%-4d  -  holds %d -> %d (%d/%d)",
                can_upgrade_price(p), p->waterMax, p->waterMax + 10,
                p->canUpgrades, MAX_CAN_UPGRADES);
    else
        ui_text(16, 10, " 9) Bigger Can       " C_DIM "SOLD OUT (maxed)" C_RESET);
    (void)qty;
}

static void draw_sell(const GameState *gs)
{
    ui_text(7, 10, C_BWHITE "  #  Item      Have   Price today          Value" C_RESET);
    for (int c = 0; c < CROP_COUNT; c++) {
        int price = shop_sell_price(gs, c);
        ui_text(8 + c, 10, " %d) %-9s x%-4d $%-4d (%3d%% of base)  $%d",
                c + 1, crop_info(c)->name, gs->inv.crops[c], price,
                gs->priceMod[c], price * gs->inv.crops[c]);
    }
    ui_text(14, 10, " 7) Wood      x%-4d $%-4d (fixed)           $%d",
            gs->inv.wood, WOOD_PRICE, gs->inv.wood * WOOD_PRICE);
    ui_text(16, 10, C_BGREEN " A) SELL EVERYTHING" C_RESET "                         $%d", sell_value_all(gs));
}

void shop_run(GameState *gs)
{
    static const int QTYS[3] = { 1, 5, 10 };
    int tab = 0, qi = 0;
    char note[100];
    snprintf(note, sizeof note, "%s", gs->festival ? "Harvest Fair today: prices are up 25%!"
                                                  : "Welcome! What can I get you?");

    for (;;) {
        ui_begin();
        ui_render_game(gs);
        ui_box(3, 8, 62, 22, gs->festival ? " GENERAL STORE  *FAIR DAY* " : " GENERAL STORE ");
        ui_text(5, 10, "%s[B] BUY" C_RESET "   %s[S] SELL" C_RESET "      Qty: x%d [+/-]     Money: " C_BYELLOW "$%d" C_RESET,
                tab == 0 ? C_BYELLOW : C_DIM, tab == 1 ? C_BYELLOW : C_DIM,
                QTYS[qi], gs->player.money);
        ui_text(6, 10, "----------------------------------------------------------");
        if (tab == 0) draw_buy(gs, QTYS[qi]); else draw_sell(gs);
        ui_text(18, 10, "----------------------------------------------------------");
        ui_text(19, 10, C_BCYAN "%s" C_RESET, note);
        ui_text(22, 10, tab == 0 ? "[1-9] Buy   [+/-] Quantity   [S] Sell tab   [Esc] Leave"
                                 : "[1-7] Sell  [+/-] Quantity   [A] Sell all   [B] Buy tab   [Esc] Leave");
        ui_flush();

        int k = ui_get_key(-1);
        if (k == KEY_EOF) { gs->quit = true; return; }
        if (k == KEY_NONE) continue;
        if (k < 256 && k >= 'A' && k <= 'Z') k += 32;

        if (k == KEY_ESC || k == 'q') return;
        if (k == 'b') tab = 0;
        else if (k == 's') tab = 1;
        else if (k == '\t') tab = !tab;
        else if (k == '+' || k == '=') { if (qi < 2) qi++; }
        else if (k == '-' || k == '_') { if (qi > 0) qi--; }
        else if (tab == 0 && k >= '1' && k <= '9') {
            buy(gs, k - '0', QTYS[qi], note, sizeof note);
        } else if (tab == 1 && k >= '1' && k <= '7') {
            int earned = sell_item(gs, k - '0', QTYS[qi]);
            if (earned > 0) snprintf(note, sizeof note, "Sold for $%d. Pleasure doing business!", earned);
            else snprintf(note, sizeof note, "You have none of that to sell.");
            game_check_progress(gs);
        } else if (tab == 1 && k == 'a') {
            int total = 0;
            for (int i = 1; i <= 7; i++) total += sell_item(gs, i, 100000);
            if (total > 0) snprintf(note, sizeof note, "Sold everything for $%d!", total);
            else snprintf(note, sizeof note, "Your pockets are empty.");
            game_check_progress(gs);
        }
    }
}
