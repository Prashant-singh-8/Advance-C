/*
 * farm.c - world generation, tile queries and per-tile farming actions.
 * No terminal I/O happens here; game.c decides what to tell the player.
 */
#include <stdlib.h>
#include <string.h>
#include "farm.h"
#include "crop.h"

/* ---------------------------------------------------------------- helpers */

bool farm_in_bounds(int x, int y)
{
    return x >= 0 && y >= 0 && x < MAP_W && y < MAP_H;
}

Tile *farm_tile(Farm *f, int x, int y)
{
    return farm_in_bounds(x, y) ? &f->tiles[y][x] : NULL;
}

const Tile *farm_tile_c(const Farm *f, int x, int y)
{
    return farm_in_bounds(x, y) ? &f->tiles[y][x] : NULL;
}

/* Collision detection: only open ground can be walked on. */
bool farm_walkable(const Farm *f, int x, int y)
{
    const Tile *t = farm_tile_c(f, x, y);
    if (!t) return false;
    switch (t->type) {
    case TILE_GRASS: case TILE_PATH: case TILE_FLOWER: case TILE_SOIL:
        return true;
    default:
        return false;
    }
}

static void set_tile(Farm *f, int x, int y, TileType type, char ch)
{
    Tile *t = farm_tile(f, x, y);
    if (!t) return;
    memset(t, 0, sizeof *t);
    t->type = (uint8_t)type;
    t->ch = ch;
    t->crop = NO_CROP;
}

static void clear_rect(Farm *f, int x0, int y0, int x1, int y1)
{
    for (int y = y0; y <= y1; y++)
        for (int x = x0; x <= x1; x++)
            set_tile(f, x, y, TILE_GRASS, 0);
}

static void stamp(Farm *f, int x0, int y0, const char *const *rows, int h,
                  TileType type, char doorCh)
{
    for (int r = 0; r < h; r++) {
        for (int c = 0; rows[r][c]; c++) {
            char ch = rows[r][c];
            set_tile(f, x0 + c, y0 + r, (doorCh && ch == doorCh) ? TILE_DOOR : type, ch);
        }
    }
}

/* -------------------------------------------------------- map generation */

void farm_generate(Farm *f)
{
    memset(f, 0, sizeof *f);
    clear_rect(f, 0, 0, MAP_W - 1, MAP_H - 1);

    /* 1. Forest around the edges, thinner towards the middle. */
    for (int y = 0; y < MAP_H; y++) {
        for (int x = 0; x < MAP_W; x++) {
            bool forest = x <= 17 || x >= 74 || y <= 3 || y >= 35;
            if (!forest) continue;
            int edge = x < y ? x : y;
            if (MAP_W - 1 - x < edge) edge = MAP_W - 1 - x;
            if (MAP_H - 1 - y < edge) edge = MAP_H - 1 - y;
            int density = edge <= 2 ? 96 : 72;
            if (rand() % 100 < density) set_tile(f, x, y, TILE_TREE, 'T');
        }
    }

    /* 2. Meadow scenery: lone trees, rocks, flowers. */
    for (int i = 0; i < 45; i++)
        set_tile(f, 18 + rand() % 56, 4 + rand() % 31, TILE_TREE, 'T');
    for (int i = 0; i < 28; i++)
        set_tile(f, 18 + rand() % 56, 4 + rand() % 31, TILE_ROCK, 'o');
    for (int i = 0; i < 90; i++) {
        int x = 18 + rand() % 56, y = 4 + rand() % 31;
        if (f->tiles[y][x].type == TILE_GRASS) set_tile(f, x, y, TILE_FLOWER, '*');
    }

    /* 3. Clear the working areas: field, house yard, market. */
    clear_rect(f, 20, 12, 54, 32);
    clear_rect(f, 24, 3, 48, 12);
    clear_rect(f, 53, 4, 70, 12);
    clear_rect(f, 54, 16, 73, 31);

    /* 4. Field fence with three gates (north, east, west). */
    for (int x = FIELD_X0; x <= FIELD_X1; x++) {
        set_tile(f, x, FIELD_Y0, TILE_FENCE, '#');
        set_tile(f, x, FIELD_Y1, TILE_FENCE, '#');
    }
    for (int y = FIELD_Y0; y <= FIELD_Y1; y++) {
        set_tile(f, FIELD_X0, y, TILE_FENCE, '#');
        set_tile(f, FIELD_X1, y, TILE_FENCE, '#');
    }
    set_tile(f, 33, FIELD_Y0, TILE_PATH, ':');
    set_tile(f, FIELD_X1, 22, TILE_PATH, ':');
    set_tile(f, FIELD_X0, 22, TILE_PATH, ':');

    /* 5. Storage yard with a chest, fenced, gap facing the path. */
    for (int x = 38; x <= 44; x++) {
        set_tile(f, x, 5, TILE_FENCE, '#');
        set_tile(f, x, 8, TILE_FENCE, '#');
    }
    for (int y = 5; y <= 8; y++) {
        set_tile(f, 38, y, TILE_FENCE, '#');
        set_tile(f, 44, y, TILE_FENCE, '#');
    }
    set_tile(f, 41, 8, TILE_PATH, ':');
    set_tile(f, 41, 6, TILE_CHEST, 'C');

    /* 6. Pond (two overlapping ellipses). */
    for (int y = 16; y <= 31; y++) {
        for (int x = 54; x <= 73; x++) {
            int dx = x - 65, dy = y - 24;
            bool big = dx * dx * 25 + dy * dy * 64 <= 64 * 25;
            int dx2 = x - 60, dy2 = y - 27;
            bool small = dx2 * dx2 * 9 + dy2 * dy2 * 16 <= 16 * 9;
            if (big || small) set_tile(f, x, y, TILE_WATER, '~');
        }
    }

    /* 7. Paths linking everything. */
    for (int x = 17; x <= 66; x++) set_tile(f, x, 10, TILE_PATH, ':');   /* main road  */
    for (int y = 9; y <= FIELD_Y0; y++) set_tile(f, 33, y, TILE_PATH, ':'); /* house->field */
    for (int y = 10; y <= 22; y++) set_tile(f, 54, y, TILE_PATH, ':');   /* to east gate */
    for (int x = 53; x <= 56; x++) set_tile(f, x, 22, TILE_PATH, ':');   /* to the pond  */
    for (int x = 58; x <= 65; x++) set_tile(f, x, 9, TILE_PATH, ':');    /* market front */
    set_tile(f, 41, 9, TILE_PATH, ':');
    for (int x = 18; x < FIELD_X0; x++) set_tile(f, x, 22, TILE_PATH, ':');  /* west trail */

    /* 8. Buildings. */
    static const char *const HOUSE[3]  = { "/^^^^^\\", "|HoHoH|", "|HHDHH|" };
    static const char *const MARKET[3] = { "/$$$$$$\\", "|MARKET|", "|$$$$$$|" };
    stamp(f, 30, 6, HOUSE, 3, TILE_HOUSE, 'D');
    stamp(f, 58, 6, MARKET, 3, TILE_SHOP, 0);
    f->doorX = 33;
    f->doorY = 8;

    /* 9. A few flowers around the house for charm. */
    for (int i = 0; i < 24; i++) {
        int x = 26 + rand() % 21, y = 4 + rand() % 8;
        if (f->tiles[y][x].type == TILE_GRASS) set_tile(f, x, y, TILE_FLOWER, '*');
    }
    /* Keep the spot in front of the door and the start tile clear. */
    set_tile(f, 33, 9, TILE_PATH, ':');
}

/* Describe the region for the side panel. */
const char *farm_area_name(int x, int y)
{
    if (x >= 38 && x <= 44 && y >= 5 && y <= 9)                       return "Storage Yard";
    if (x >= 25 && x <= 47 && y >= 4 && y <= 12)                      return "Farmhouse";
    if (x >= 53 && x <= 70 && y >= 4 && y <= 12)                      return "Market Square";
    if (x >= FIELD_X0 && x <= FIELD_X1 && y >= FIELD_Y0 && y <= FIELD_Y1) return "Farm Field";
    if (x >= 54 && x <= 73 && y >= 16 && y <= 31)                     return "Pond Shore";
    if (x <= 17 || x >= 74 || y <= 3 || y >= 35)                      return "Forest";
    return "Meadow";
}

/* ------------------------------------------------------ farming actions */

bool farm_till(Tile *t)
{
    if (t->type != TILE_GRASS && t->type != TILE_FLOWER) return false;
    memset(t, 0, sizeof *t);
    t->type = TILE_SOIL;
    t->ch = '=';
    t->crop = NO_CROP;
    return true;
}

bool farm_plant(Tile *t, int crop)
{
    if (t->type != TILE_SOIL || t->crop != NO_CROP) return false;
    t->crop = (int8_t)crop;
    t->growth = 0;
    t->dry = 0;
    t->withered = 0;
    return true;
}

bool farm_water(Tile *t)
{
    if (t->type != TILE_SOIL || t->watered) return false;
    t->watered = 1;
    return true;
}

/* Returns the harvested crop type, or NO_CROP if nothing was ripe. */
int farm_harvest(Tile *t)
{
    if (t->type != TILE_SOIL || !crop_ready(t)) return NO_CROP;
    int crop = t->crop;
    const CropInfo *ci = crop_info(crop);
    if (ci->regrowDays > 0) {            /* bushes keep producing */
        t->growth = (uint8_t)(ci->growDays - ci->regrowDays);
        t->dry = 0;
    } else {
        t->crop = NO_CROP;
        t->growth = 0;
        t->dry = 0;
    }
    return crop;
}

void farm_clear_dead(Tile *t)
{
    t->crop = NO_CROP;
    t->growth = 0;
    t->dry = 0;
    t->withered = 0;
}

bool farm_fertilize(Tile *t)
{
    if (t->type != TILE_SOIL || t->crop == NO_CROP || t->withered) return false;
    if (crop_ready(t)) return false;
    t->growth++;
    return true;
}

void farm_chop(Tile *t)
{
    memset(t, 0, sizeof *t);
    t->type = TILE_GRASS;
    t->crop = NO_CROP;
}

/* ------------------------------------------------------- daily processing */

/*
 * Run once each night.  A crop grows one day if it was watered; after 3 dry
 * days in a row it withers.  Watering flags are then reset for tomorrow.
 */
void farm_new_day(Farm *f, DayReport *rep)
{
    memset(rep, 0, sizeof *rep);
    for (int y = 0; y < MAP_H; y++) {
        for (int x = 0; x < MAP_W; x++) {
            Tile *t = &f->tiles[y][x];
            if (t->type != TILE_SOIL) continue;
            if (t->crop != NO_CROP && !t->withered && !crop_ready(t)) {
                if (t->watered) {
                    t->growth++;
                    t->dry = 0;
                    rep->grown++;
                    if (crop_ready(t)) rep->newlyRipe++;
                } else if (++t->dry >= 3) {
                    t->withered = 1;
                    rep->withered++;
                }
            }
            t->watered = 0;
        }
    }
}

void farm_apply_rain(Farm *f)
{
    for (int y = 0; y < MAP_H; y++)
        for (int x = 0; x < MAP_W; x++)
            if (f->tiles[y][x].type == TILE_SOIL) f->tiles[y][x].watered = 1;
}

int farm_storm_damage(Farm *f)
{
    int lost = 0;
    for (int y = 0; y < MAP_H; y++) {
        for (int x = 0; x < MAP_W; x++) {
            Tile *t = &f->tiles[y][x];
            if (t->type == TILE_SOIL && t->crop != NO_CROP && rand() % 100 < 7) {
                farm_clear_dead(t);
                lost++;
            }
        }
    }
    return lost;
}

/* Crops that are not unripe-and-suited to the new season wither ("frost"). */
int farm_season_frost(Farm *f, Season s)
{
    int n = 0;
    for (int y = 0; y < MAP_H; y++) {
        for (int x = 0; x < MAP_W; x++) {
            Tile *t = &f->tiles[y][x];
            if (t->type != TILE_SOIL || t->crop == NO_CROP || t->withered) continue;
            if (!crop_ready(t) && !crop_in_season(t->crop, s)) {
                t->withered = 1;
                n++;
            }
        }
    }
    return n;
}

/* Crows destroy one random growing crop. Returns 1 if one was eaten. */
int farm_crow_attack(Farm *f)
{
    int cx[MAP_W * MAP_H], cy[MAP_W * MAP_H], n = 0;
    for (int y = 0; y < MAP_H; y++) {
        for (int x = 0; x < MAP_W; x++) {
            const Tile *t = &f->tiles[y][x];
            if (t->type == TILE_SOIL && t->crop != NO_CROP && !crop_ready(t) && !t->withered) {
                cx[n] = x;
                cy[n] = y;
                n++;
            }
        }
    }
    if (n == 0) return 0;
    int k = rand() % n;
    farm_clear_dead(&f->tiles[cy[k]][cx[k]]);
    return 1;
}

void farm_count_crops(const Farm *f, int *planted, int *ripe)
{
    *planted = 0;
    *ripe = 0;
    for (int y = 0; y < MAP_H; y++) {
        for (int x = 0; x < MAP_W; x++) {
            const Tile *t = &f->tiles[y][x];
            if (t->type == TILE_SOIL && t->crop != NO_CROP && !t->withered) {
                (*planted)++;
                if (crop_ready(t)) (*ripe)++;
            }
        }
    }
}
