/* save.h - save and load the whole game to a binary file. */
#ifndef SAVE_H
#define SAVE_H

#include "types.h"

bool save_game(const GameState *gs, const char *path);
bool load_game(GameState *gs, const char *path);
bool save_exists(const char *path);

#endif
