/* inventory.h - backpack and chest bookkeeping. */
#ifndef INVENTORY_H
#define INVENTORY_H

#include "types.h"

void inv_init(Inventory *inv);
int  inv_total_crops(const Inventory *inv);
int  inv_total_seeds(const Inventory *inv);
int  inv_chest_total(const Inventory *inv);
void inv_deposit_all(Inventory *inv);
void inv_withdraw_all(Inventory *inv);

/* Chest menu (uses ui overlays). */
void chest_run(GameState *gs);

#endif
