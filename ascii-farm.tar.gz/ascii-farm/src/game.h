/* game.h - the coordinator: rules, clock, actions, main loop. */
#ifndef GAME_H
#define GAME_H

#include "types.h"

/* Energy and time costs of each action (minutes of game time). */
#define COST_TILL 3
#define COST_PLANT 1
#define COST_WATER 1
#define COST_HARVEST 2
#define COST_FERT 1
#define COST_CHOP 4

void game_new(GameState *gs);
void game_msg(GameState *gs, const char *fmt, ...);
void game_advance_time(GameState *gs, int minutes);
void game_sleep(GameState *gs, bool passedOut);
void game_gain_xp(GameState *gs, int xp);
void game_check_progress(GameState *gs);
void game_handle_key(GameState *gs, int key);
void game_run(GameState *gs);                 /* the main loop */

const char *season_name(Season s);
const char *weather_name(WeatherType w, Season s);

#endif
